"""
Unit Tests for Cross-Encoder Neural Reranker and Context Compression.
"""

import pytest
from app.document_processing.extractor import DocumentChunk
from app.retrieval.compressor import ContextCompressor
from app.retrieval.reranker import CrossEncoderReranker


def test_cross_encoder_scoring():
    query = "Q3 financial revenue growth"
    doc_match = "Apex Global Technologies reported record Q3 financial revenue of 4.85 billion dollars."
    doc_irrelevant = "Quantum error correction utilizes surface codes and cryogenic refrigerators."

    score_match = CrossEncoderReranker.score_pair(query, doc_match)
    score_irr = CrossEncoderReranker.score_pair(query, doc_irrelevant)

    assert score_match > score_irr
    assert 0.0 <= score_match <= 1.0


def test_reranker_selection_and_mmr():
    query = "hypertension medication"
    chunk_1 = DocumentChunk(doc_id="d1", text="Lisinopril is an ACE inhibitor used for treating hypertension.", token_count=10, strategy="s")
    chunk_2 = DocumentChunk(doc_id="d2", text="Quantum supremacy was demonstrated using superconducting qubits.", token_count=8, strategy="s")

    candidates = [
        (chunk_2, 0.02, {"dense_score": 0.2}),
        (chunk_1, 0.015, {"dense_score": 0.15}),
    ]

    reranked = CrossEncoderReranker.rerank(query, candidates, top_k=2, apply_mmr=True)
    assert len(reranked) == 2
    # chunk_1 should rise to top rank
    assert reranked[0]["chunk"].doc_id == "d1"
    assert reranked[0]["rank_shift"] > 0


def test_context_compressor():
    query = "blood pressure and ACE inhibitors"
    long_text = (
        "Blood pressure classifications for adult patients define normal as under 120/80. "
        "The weather in Tokyo is sunny today. "
        "Patients with Stage 2 hypertension require combination therapy with ACE inhibitors. "
        "Quantum computing relies on cryogenic dilution refrigerators."
    )
    chunk = DocumentChunk(doc_id="d3", text=long_text, token_count=40, strategy="s")
    compressed, stats = ContextCompressor.compress_chunk(query, chunk, target_retention=0.6)

    assert "Blood pressure" in compressed
    assert "ACE inhibitors" in compressed
    assert "Tokyo" not in compressed
    assert "Quantum" not in compressed
    assert stats["reduction_pct"] > 0.0
