"""
Unit Tests for Voice Subsystems: VAD, STT, and TTS Synthesizer.
"""

import base64
import numpy as np
import pytest
from app.voice.stt import SpeechToTextEngine
from app.voice.tts import TextToSpeechEngine
from app.voice.vad import VoiceActivityDetector


def test_vad_speech_detection():
    vad = VoiceActivityDetector(sample_rate=16000)
    # Generate synthetic speech-like tone (200Hz sine wave)
    t = np.linspace(0, 1.0, 16000, endpoint=False)
    synthetic_speech = (0.5 * np.sin(2 * np.pi * 200 * t) * 32767).astype(np.int16)

    has_speech, energy, intervals = vad.detect_speech_segments(synthetic_speech)
    assert has_speech is True
    assert energy > 0.01
    assert len(intervals) > 0


def test_tts_synthesizer():
    tts = TextToSpeechEngine(sample_rate=24000)
    res = tts.synthesize("Welcome to the Voice-Enabled RAG System.", voice="alloy", speed=1.0)

    assert res.duration_sec > 0.5
    assert len(res.audio_base64) > 100
    assert res.format == "audio/wav"

    # Decode and check RIFF header
    raw_wav = base64.b64decode(res.audio_base64)
    assert raw_wav.startswith(b"RIFF")
    assert b"WAVE" in raw_wav[:12]


def test_stt_transcription():
    stt = SpeechToTextEngine()
    dummy_pcm = np.zeros(16000, dtype=np.int16).tobytes()
    res = stt.transcribe_audio_bytes(dummy_pcm)
    assert res.duration_sec > 0.5
    assert res.detected_language == "en"
