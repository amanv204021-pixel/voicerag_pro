"""
Unit Tests for Benchmark Suite and Evaluators.
"""

import pytest
from app.benchmarks.embedding_bench import EmbeddingBenchmarkRunner
from app.benchmarks.evaluator import RetrievalEvaluator
from app.benchmarks.latency_bench import LatencyBenchmarkSuite


def test_retrieval_evaluator_metrics():
    eval_cases = [
        {"retrieved_ids": ["c1", "c2", "c3", "c4", "c5"], "ground_truth_ids": {"c1", "c2"}},
        {"retrieved_ids": ["c4", "c1", "c5", "c6", "c7"], "ground_truth_ids": {"c1"}},
    ]
    report = RetrievalEvaluator.evaluate_benchmark_suite(eval_cases)
    assert report["recall_at_5"] == 1.0
    assert report["mrr"] > 0.5
    assert report["ndcg_at_5"] > 0.5
    assert report["total_eval_queries"] == 2


def test_embedding_comparative_matrix():
    matrix = EmbeddingBenchmarkRunner.get_comparative_matrix()
    assert "models" in matrix
    assert len(matrix["models"]) >= 5
    assert matrix["selected_model"] == "BAAI/bge-large-en-v1.5"


def test_latency_profiler():
    profile = LatencyBenchmarkSuite.run_profiling_simulation(iterations=20)
    assert "e2e_latency_ms" in profile
    assert profile["e2e_latency_ms"]["p50"] > 0
    assert profile["e2e_latency_ms"]["p99"] >= profile["e2e_latency_ms"]["p50"]
    assert "naive_rag" in profile["architecture_comparison"]
