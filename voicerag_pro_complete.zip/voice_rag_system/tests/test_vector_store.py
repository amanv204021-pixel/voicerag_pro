"""
Unit Tests for Vector Database Store.
"""

import os
import shutil
import tempfile
import pytest
from app.document_processing.extractor import DocumentChunk
from app.retrieval.vector_store import VectorStore


@pytest.fixture
def temp_vector_store():
    tmp_dir = tempfile.mkdtemp()
    vs = VectorStore(storage_dir=tmp_dir)
    chunks = [
        DocumentChunk(
            doc_id="doc_a",
            text="Voice-enabled RAG systems provide streaming speech transcription and hybrid search.",
            token_count=12,
            strategy="semantic",
            page=1,
            section_title="Voice RAG",
            metadata={"category": "ai"},
        ),
        DocumentChunk(
            doc_id="doc_b",
            text="Hypertension treatment includes ACE inhibitors, ARBs, and CCBs with sodium restriction.",
            token_count=13,
            strategy="semantic",
            page=1,
            section_title="Medical",
            metadata={"category": "health"},
        ),
    ]
    vs.add_chunks(chunks)
    yield vs
    shutil.rmtree(tmp_dir)


def test_vector_store_search(temp_vector_store):
    results = temp_vector_store.search_by_text("speech transcription and voice RAG", top_k=1)
    assert len(results) == 1
    chunk, score = results[0]
    assert chunk.doc_id == "doc_a"
    assert score > 0.0


def test_vector_store_metadata_filter(temp_vector_store):
    results = temp_vector_store.search_by_text(
        "treatment guidelines",
        top_k=2,
        filter_metadata={"category": "health"},
    )
    assert len(results) == 1
    assert results[0][0].doc_id == "doc_b"


def test_vector_store_persistence(temp_vector_store):
    # Create new instance pointing to same storage
    loaded_vs = VectorStore(storage_dir=temp_vector_store.storage_dir)
    assert len(loaded_vs.chunks) == 2
    assert loaded_vs.vector_matrix is not None
    assert len(loaded_vs.vector_matrix) == 2
