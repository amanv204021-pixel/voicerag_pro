"""
Unit Tests for BM25 Keyword Search Engine.
"""

import pytest
from app.document_processing.extractor import DocumentChunk
from app.retrieval.bm25 import BM25Index


@pytest.fixture
def bm25_engine():
    idx = BM25Index(k1=1.5, b=0.75)
    chunks = [
        DocumentChunk(
            doc_id="doc_1",
            text="Apex Global Technologies reported record revenue of 4.85 billion dollars in Q3 2026.",
            token_count=15,
            strategy="recursive",
            page=1,
            section_title="Financials",
        ),
        DocumentChunk(
            doc_id="doc_1",
            text="The Cloud AI division grew forty two percent year over year, generating 2.65 billion.",
            token_count=16,
            strategy="recursive",
            page=1,
            section_title="Segment",
        ),
        DocumentChunk(
            doc_id="doc_2",
            text="Topological quantum computing uses surface codes and 127 physical data qubits.",
            token_count=14,
            strategy="recursive",
            page=1,
            section_title="Quantum",
        ),
    ]
    idx.add_chunks(chunks)
    return idx


def test_bm25_search_exact_match(bm25_engine):
    results = bm25_engine.search("revenue 4.85 billion", top_k=2)
    assert len(results) > 0
    top_chunk, score = results[0]
    assert "4.85 billion" in top_chunk.text
    assert score > 0


def test_bm25_search_quantum(bm25_engine):
    results = bm25_engine.search("quantum surface codes qubits", top_k=1)
    assert len(results) == 1
    top_chunk, score = results[0]
    assert "Topological quantum" in top_chunk.text


def test_bm25_remove_document(bm25_engine):
    removed = bm25_engine.remove_document("doc_1")
    assert removed == 2
    res = bm25_engine.search("revenue", top_k=5)
    assert len(res) == 0
    # doc_2 remains
    res_q = bm25_engine.search("quantum", top_k=5)
    assert len(res_q) == 1
