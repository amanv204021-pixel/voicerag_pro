"""
Additional Comprehensive Test Cases for 95%+ Full System Coverage.
"""

import asyncio
import io
import time
import numpy as np
import pytest
from docx import Document as DocxDocument
from pypdf import PdfWriter
from fastapi.testclient import TestClient

from app.core.cache import LRUCache, cache
from app.core.circuit_breaker import CircuitBreaker, CircuitBreakerOpenException, CircuitState, retry_with_backoff
from app.core.logging import JSONFormatter, setup_logger
from app.document_processing.chunkers import AutoChunker
from app.document_processing.parsers import DocxParser, HTMLParser, PDFParser
from app.llm.engine import GroundedLLMEngine
from app.main import app, seed_sample_knowledge_base
from app.retrieval.graph import knowledge_graph_engine
from app.retrieval.reranker import CrossEncoderReranker
from app.retrieval.vector_store import vector_store
from app.voice.stt import SpeechToTextEngine
from app.voice.vad import VoiceActivityDetector

client = TestClient(app)


def test_circuit_breaker_and_retry():
    cb = CircuitBreaker("test_service", failure_threshold=2, recovery_timeout=0.1)

    def failing_func():
        raise ValueError("Simulated network failure")

    # Trip the circuit
    with pytest.raises(ValueError):
        cb.call(failing_func)
    assert cb.state == CircuitState.CLOSED

    with pytest.raises(ValueError):
        cb.call(failing_func)
    assert cb.state == CircuitState.OPEN

    # Call while open should raise CircuitBreakerOpenException immediately
    with pytest.raises(CircuitBreakerOpenException):
        cb.call(failing_func)

    # Wait for recovery timeout
    time.sleep(0.15)

    def succeeding_func():
        return "success"

    res = cb.call(succeeding_func)
    assert res == "success"
    assert cb.get_status()["state"] in [CircuitState.HALF_OPEN, CircuitState.CLOSED]

    # Test retry decorator
    attempts = 0

    @retry_with_backoff(max_retries=3, initial_delay=0.01)
    def flaky_func():
        nonlocal attempts
        attempts += 1
        if attempts < 3:
            raise RuntimeError("Transient error")
        return "recovered"

    assert flaky_func() == "recovered"
    assert attempts == 3


def test_cache_comprehensive():
    c = LRUCache(max_size=3, default_ttl_sec=1)
    c.set("k1", "v1")
    c.set("k2", "v2")
    c.set("k3", "v3")
    assert c.get("k1") == "v1"

    # Eviction on exceeding max_size
    c.set("k4", "v4")
    assert c.get("k2") is None  # k2 was least recently used since k1 was read

    # Invalidation & Clear
    assert c.invalidate("k4") is True
    assert c.get("k4") is None
    stats = c.get_stats()
    assert stats["hits"] > 0
    c.clear()
    assert stats["max_size"] == 3


def test_pdf_and_docx_parsers_binary():
    # 1. Create a dummy PDF in memory
    pdf_writer = PdfWriter()
    pdf_writer.add_blank_page(width=72, height=72)
    pdf_bytes_io = io.BytesIO()
    pdf_writer.write(pdf_bytes_io)
    pdf_bytes = pdf_bytes_io.getvalue()
    pdf_doc = PDFParser.parse(pdf_bytes, "generated_test.pdf")
    assert pdf_doc.file_type == "pdf"
    assert pdf_doc.total_pages == 1

    # 2. Create a dummy DOCX in memory
    docx = DocxDocument()
    docx.add_heading("Architecture Overview", level=1)
    docx.add_paragraph("This is a test paragraph detailing RAG pipeline performance.")
    table = docx.add_table(rows=2, cols=2)
    table.cell(0, 0).text = "Metric"
    table.cell(0, 1).text = "Target"
    table.cell(1, 0).text = "Latency"
    table.cell(1, 1).text = "<800ms"
    docx_bytes_io = io.BytesIO()
    docx.save(docx_bytes_io)
    docx_bytes = docx_bytes_io.getvalue()

    docx_doc = DocxParser.parse(docx_bytes, "generated_test.docx")
    assert docx_doc.file_type == "docx"
    assert len(docx_doc.sections) >= 2


def test_benchmark_run_endpoint():
    res = client.post("/api/benchmark/run", json={"queries": ["What is RAG?", "How does BM25 work?"]})
    assert res.status_code == 200
    data = res.json()
    assert data["status"] == "completed"
    assert "retrieval_metrics" in data


def test_voice_transcribe_and_voice_rag_endpoints():
    # Test transcribe endpoint with empty vs audio bytes
    audio_data = b"RIFF" + b"\x00" * 1000
    res_tr = client.post("/api/voice/transcribe", files={"file": ("speech.wav", audio_data, "audio/wav")})
    assert res_tr.status_code == 200
    assert "transcript" in res_tr.json()

    # Test full voice-to-voice RAG endpoint
    res_voice = client.post(
        "/api/voice",
        files={"file": ("speech.wav", audio_data, "audio/wav")},
        data={"voice": "alloy", "speed": "1.0"},
    )
    assert res_voice.status_code == 200
    v_data = res_voice.json()
    assert "audio_base64" in v_data
    assert "query_transcript" in v_data
    assert "latency_waterfall" in v_data


def test_knowledge_graph_and_seed():
    seed_sample_knowledge_base()
    graph_data = knowledge_graph_engine.build_graph()
    assert "nodes" in graph_data
    assert "links" in graph_data
    assert graph_data["summary"]["total_nodes"] > 0


def test_streaming_ask_endpoint():
    with client.stream("GET", "/api/ask/stream?query=What+is+RAG&top_k=3") as response:
        assert response.status_code == 200
        content = ""
        for chunk in response.iter_lines():
            content += chunk.decode("utf-8") if isinstance(chunk, bytes) else chunk
        assert "event:" in content


def test_interruption_and_vad():
    vad = VoiceActivityDetector()
    stt = SpeechToTextEngine()
    dummy_noise = (np.random.normal(0, 0.001, 1600) * 32767).astype(np.int16).tobytes()
    assert stt.check_speaker_interruption(dummy_noise) is False
