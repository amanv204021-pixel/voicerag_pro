"""
Unit Tests for Multi-Format Document Parsers.
"""

import pytest
from app.document_processing.parsers import (
    CSVParser,
    DocxParser,
    HTMLParser,
    MarkdownParser,
    PDFParser,
    TextParser,
    DocumentParserRouter,
)


def test_markdown_parser():
    md_content = b"# Main Title\n\nIntroduction paragraph.\n\n## Section A\n\nContent for section A.\n\n## Section B\n\nContent for section B."
    doc = MarkdownParser.parse(md_content, "test.md")
    assert doc.title == "Main Title"
    assert doc.file_type == "md"
    assert len(doc.sections) >= 2
    assert "Section A" in [s.title for s in doc.sections]


def test_csv_parser():
    csv_content = b"Name,Role,Department\nAlice,Engineer,AI\nBob,Architect,Platform\nCharlie,Scientist,Research"
    doc = CSVParser.parse(csv_content, "test.csv")
    assert doc.file_type == "csv"
    assert len(doc.sections) == 1
    assert "Alice" in doc.full_text
    assert "Engineer" in doc.full_text
    assert doc.metadata["row_count"] == 3


def test_html_parser():
    html_content = b"<html><head><title>System Spec</title></head><body><h1>Architecture</h1><p>High performance RAG system.</p><h2>Latency</h2><p>P95 is under 800ms.</p></body></html>"
    doc = HTMLParser.parse(html_content, "test.html")
    assert doc.file_type == "html"
    assert doc.title == "System Spec"
    assert len(doc.sections) >= 2
    assert "P95 is under 800ms" in doc.full_text


def test_text_parser():
    txt_content = b"Paragraph 1 details about the system.\n\nParagraph 2 details about the vector database."
    doc = TextParser.parse(txt_content, "notes.txt")
    assert doc.file_type == "txt"
    assert len(doc.sections) == 2
    assert doc.total_tokens > 0


def test_document_parser_router():
    doc_md = DocumentParserRouter.parse(b"# Hello\nWorld", "sample.md")
    assert doc_md.file_type == "md"

    doc_txt = DocumentParserRouter.parse(b"Some text", "sample.txt")
    assert doc_txt.file_type == "txt"

    doc_csv = DocumentParserRouter.parse(b"a,b\n1,2", "sample.csv")
    assert doc_csv.file_type == "csv"
