"""
Unit Tests for Hybrid Retrieval Engine and Reciprocal Rank Fusion (RRF).
"""

import pytest
from app.document_processing.extractor import DocumentChunk
from app.retrieval.bm25 import bm25_index
from app.retrieval.hybrid import HybridSearchEngine, QueryExpander
from app.retrieval.vector_store import vector_store


@pytest.fixture(autouse=True)
def setup_indexes():
    vector_store.clear()
    bm25_index.clear()
    chunks = [
        DocumentChunk(
            doc_id="spec_1",
            text="Autonomous AI agents use parent-child chunking and reciprocal rank fusion to optimize retrieval quality.",
            token_count=16,
            strategy="recursive",
            page=1,
            section_title="Architecture",
        ),
        DocumentChunk(
            doc_id="fin_1",
            text="Apex Global Technologies Q3 revenue was 4.85 billion dollars with an operating margin of 29.3 percent.",
            token_count=18,
            strategy="recursive",
            page=1,
            section_title="Financials",
        ),
    ]
    vector_store.add_chunks(chunks)
    bm25_index.add_chunks(chunks)
    yield
    vector_store.clear()
    bm25_index.clear()


def test_query_expander():
    expansions = QueryExpander.expand_query("What is hybrid search in RAG?")
    assert len(expansions) >= 2
    assert "What is hybrid search in RAG?" in expansions


def test_hybrid_search_fusion():
    engine = HybridSearchEngine(rrf_k=60, dense_weight=0.65, sparse_weight=0.35)
    results = engine.search("reciprocal rank fusion parent-child chunking", top_k=2)
    assert len(results) > 0
    top_chunk, fused_score, breakdown = results[0]
    assert top_chunk.doc_id == "spec_1"
    assert fused_score > 0
    assert "dense_rank" in breakdown
    assert "sparse_rank" in breakdown
