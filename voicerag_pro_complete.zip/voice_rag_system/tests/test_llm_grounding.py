"""
Unit Tests for LLM Grounded Generation, Citation Verification, and Refusals.
"""

import pytest
from app.document_processing.extractor import DocumentChunk
from app.llm.citations import CitationValidator
from app.llm.engine import GroundedLLMEngine


def test_citation_validator_verified():
    response = "Apex Q3 revenue was 4.85 billion [Doc: apex_earnings.txt, Page: 1, Section: Financials]."
    retrieved = [{
        "chunk": DocumentChunk(
            doc_id="d1",
            text="Apex revenue was 4.85 billion in Q3 2026.",
            token_count=10,
            strategy="s",
            page=1,
            section_title="Financials",
            metadata={"filename": "apex_earnings.txt"},
        ),
        "score": 0.92,
    }]

    eval_result = CitationValidator.extract_and_verify(response, retrieved)
    assert eval_result.is_grounded is True
    assert len(eval_result.citations) >= 1
    assert eval_result.citations[0].filename == "apex_earnings.txt"
    assert eval_result.grounding_score > 0.6


def test_llm_grounded_answer_generation():
    engine = GroundedLLMEngine()
    query = "What was the Q3 revenue?"
    retrieved = [{
        "chunk": DocumentChunk(
            doc_id="d1",
            text="Apex Global Technologies reported record Q3 2026 revenue of $4.85 Billion with strong growth.",
            token_count=15,
            strategy="recursive",
            page=1,
            section_title="Financials",
            metadata={"filename": "earnings.txt"},
        ),
        "score": 0.88,
        "compressed_text": "Apex Global Technologies reported record Q3 2026 revenue of $4.85 Billion.",
    }]

    rag_res = engine.generate_grounded_answer(query, retrieved)
    assert rag_res.refused is False
    assert "$4.85 Billion" in rag_res.answer or "4.85" in rag_res.answer
    assert rag_res.grounding_score > 0.5
    assert len(rag_res.citations) > 0


def test_llm_refusal_when_insufficient():
    engine = GroundedLLMEngine()
    query = "What is the secret recipe for dark chocolate cake?"
    rag_res = engine.generate_grounded_answer(query, [])
    assert rag_res.refused is True
    assert "cannot answer" in rag_res.answer.lower()
