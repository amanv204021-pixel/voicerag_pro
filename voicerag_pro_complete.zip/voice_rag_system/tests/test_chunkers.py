"""
Unit Tests for Adaptive Multi-Strategy Chunkers.
"""

import pytest
from app.document_processing.chunkers import (
    AutoChunker,
    ParentChildChunker,
    RecursiveChunker,
    SemanticChunker,
    SentenceAwareChunker,
    SlidingWindowChunker,
)
from app.document_processing.extractor import DocumentSection, ParsedDocument


@pytest.fixture
def sample_parsed_document():
    long_text = " ".join([f"This is sentence number {i} discussing voice RAG systems and low latency." for i in range(1, 50)])
    sections = [
        DocumentSection(title="Section 1", level=1, content=long_text[:400], page=1),
        DocumentSection(title="Section 2", level=2, content=long_text[400:], page=2),
    ]
    return ParsedDocument(
        filename="rag_specs.md",
        file_type="md",
        title="RAG Specifications",
        sections=sections,
        full_text=long_text,
        total_pages=2,
        total_tokens=len(long_text.split()),
    )


def test_recursive_chunker(sample_parsed_document):
    chunks = RecursiveChunker.chunk(sample_parsed_document, chunk_size=50, chunk_overlap=10)
    assert len(chunks) > 1
    for c in chunks:
        assert c.strategy == "recursive"
        assert c.doc_id == sample_parsed_document.doc_id
        assert len(c.text) > 0


def test_semantic_chunker(sample_parsed_document):
    chunks = SemanticChunker.chunk(sample_parsed_document, chunk_size=40)
    assert len(chunks) > 1
    for c in chunks:
        assert c.strategy == "semantic"
        assert c.page in [1, 2]


def test_parent_child_chunker(sample_parsed_document):
    parents, children = ParentChildChunker.chunk(
        sample_parsed_document,
        parent_size=100,
        child_size=30,
        child_overlap=5,
    )
    assert len(parents) > 0
    assert len(children) > 0
    # Every child must point to a parent
    parent_ids = {p.chunk_id for p in parents}
    for child in children:
        assert child.parent_id in parent_ids


def test_sliding_window_chunker(sample_parsed_document):
    chunks = SlidingWindowChunker.chunk(sample_parsed_document, window_size=30, overlap=10)
    assert len(chunks) > 1
    for c in chunks:
        assert c.strategy == "sliding"


def test_sentence_aware_chunker(sample_parsed_document):
    chunks = SentenceAwareChunker.chunk(sample_parsed_document, target_tokens=40)
    assert len(chunks) > 1
    for c in chunks:
        assert c.strategy == "sentence"


def test_auto_chunker_router(sample_parsed_document):
    chunks = AutoChunker.chunk_document(sample_parsed_document, strategy="auto")
    assert len(chunks) > 0
