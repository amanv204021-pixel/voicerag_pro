/**
 * Knowledge Graph & Entity Citation Network Canvas Visualizer.
 */

class KnowledgeGraphController {
  constructor() {
    this.canvas = document.getElementById('graph-canvas');
    this.ctx = this.canvas ? this.canvas.getContext('2d') : null;
    this.tooltip = document.getElementById('graph-tooltip');
    this.nodes = [];
    this.links = [];
    this.hoveredNode = null;
    this.draggedNode = null;
    this.isDragging = false;
    this.animId = null;

    this.initEvents();
  }

  initEvents() {
    if (!this.canvas) return;

    window.addEventListener('resize', () => this.resizeCanvas());
    this.resizeCanvas();

    this.canvas.addEventListener('mousemove', (e) => this.handleMouseMove(e));
    this.canvas.addEventListener('mousedown', (e) => this.handleMouseDown(e));
    window.addEventListener('mouseup', () => this.handleMouseUp());
  }

  resizeCanvas() {
    if (!this.canvas || !this.canvas.parentElement) return;
    this.canvas.width = this.canvas.parentElement.clientWidth || 800;
    this.canvas.height = this.canvas.parentElement.clientHeight || 520;
  }

  async loadGraph() {
    try {
      this.resizeCanvas();
      const res = await fetch('/api/graph');
      if (!res.ok) return;
      const data = await res.json();

      const width = this.canvas.width;
      const height = this.canvas.height;

      // Position nodes in initial radial clusters
      this.nodes = (data.nodes || []).map((n, idx) => {
        const angle = (idx / Math.max(1, data.nodes.length)) * 2 * Math.PI;
        const radius = n.type === 'document' ? 80 : n.type === 'chunk' ? 160 : 230;
        return {
          ...n,
          x: width / 2 + Math.cos(angle) * radius + (Math.random() - 0.5) * 40,
          y: height / 2 + Math.sin(angle) * radius + (Math.random() - 0.5) * 40,
          vx: 0,
          vy: 0,
          radius: n.type === 'document' ? 14 : n.type === 'chunk' ? 8 : 6,
        };
      });

      const nodeMap = new Map(this.nodes.map((n) => [n.id, n]));
      this.links = (data.links || [])
        .map((l) => ({
          source: nodeMap.get(l.source),
          target: nodeMap.get(l.target),
          relationship: l.relationship,
        }))
        .filter((l) => l.source && l.target);

      this.startSimulation();
    } catch (err) {
      console.error('Failed to load graph data:', err);
    }
  }

  startSimulation() {
    if (this.animId) cancelAnimationFrame(this.animId);

    const step = () => {
      this.updatePhysics();
      this.draw();
      this.animId = requestAnimationFrame(step);
    };
    step();
  }

  updatePhysics() {
    const width = this.canvas.width;
    const height = this.canvas.height;
    const centerX = width / 2;
    const centerY = height / 2;

    // Center gravitational pull
    for (const node of this.nodes) {
      if (node === this.draggedNode) continue;
      const dx = centerX - node.x;
      const dy = centerY - node.y;
      node.vx += dx * 0.0005;
      node.vy += dy * 0.0005;
    }

    // Node-Node Repulsion
    for (let i = 0; i < this.nodes.length; i++) {
      for (let j = i + 1; j < this.nodes.length; j++) {
        const a = this.nodes[i];
        const b = this.nodes[j];
        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const dist = Math.sqrt(dx * dx + dy * dy) || 1;
        const minDist = a.radius + b.radius + 35;

        if (dist < minDist) {
          const force = (minDist - dist) / dist * 0.08;
          if (a !== this.draggedNode) {
            a.vx -= dx * force;
            a.vy -= dy * force;
          }
          if (b !== this.draggedNode) {
            b.vx += dx * force;
            b.vy += dy * force;
          }
        }
      }
    }

    // Link Spring Attraction
    for (const link of this.links) {
      const a = link.source;
      const b = link.target;
      const dx = b.x - a.x;
      const dy = b.y - a.y;
      const dist = Math.sqrt(dx * dx + dy * dy) || 1;
      const targetDist = 60;
      const force = (dist - targetDist) * 0.003;

      if (a !== this.draggedNode) {
        a.vx += dx * force;
        a.vy += dy * force;
      }
      if (b !== this.draggedNode) {
        b.vx -= dx * force;
        b.vy -= dy * force;
      }
    }

    // Update positions with friction damping
    for (const node of this.nodes) {
      if (node === this.draggedNode) continue;
      node.vx *= 0.88;
      node.vy *= 0.88;
      node.x += node.vx;
      node.y += node.vy;

      // Keep within bounds
      node.x = Math.max(20, Math.min(width - 20, node.x));
      node.y = Math.max(20, Math.min(height - 20, node.y));
    }
  }

  draw() {
    if (!this.ctx) return;
    const ctx = this.ctx;
    ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

    // Draw Links
    ctx.lineWidth = 1;
    for (const link of this.links) {
      ctx.beginPath();
      ctx.strokeStyle = link.relationship === 'contains' ? 'rgba(99, 102, 241, 0.25)' : 'rgba(6, 182, 212, 0.2)';
      ctx.moveTo(link.source.x, link.source.y);
      ctx.lineTo(link.target.x, link.target.y);
      ctx.stroke();
    }

    // Draw Nodes
    for (const node of this.nodes) {
      const isHover = node === this.hoveredNode;
      const radius = isHover ? node.radius + 3 : node.radius;

      ctx.beginPath();
      ctx.arc(node.x, node.y, radius, 0, 2 * Math.PI);
      ctx.fillStyle = node.color || '#6366f1';
      ctx.fill();

      if (isHover) {
        ctx.lineWidth = 2;
        ctx.strokeStyle = '#ffffff';
        ctx.stroke();
      }

      // Draw label
      ctx.font = node.type === 'document' ? 'bold 11px Inter, sans-serif' : '9px Inter, sans-serif';
      ctx.fillStyle = isHover ? '#ffffff' : '#9ca3af';
      ctx.fillText(node.label, node.x + radius + 4, node.y + 3);
    }
  }

  handleMouseMove(e) {
    const rect = this.canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    if (this.isDragging && this.draggedNode) {
      this.draggedNode.x = x;
      this.draggedNode.y = y;
      return;
    }

    this.hoveredNode = null;
    for (const node of this.nodes) {
      const dx = x - node.x;
      const dy = y - node.y;
      if (Math.sqrt(dx * dx + dy * dy) <= node.radius + 4) {
        this.hoveredNode = node;
        break;
      }
    }

    if (this.hoveredNode && this.tooltip) {
      this.tooltip.classList.remove('hidden');
      this.tooltip.style.left = `${x + 15}px`;
      this.tooltip.style.top = `${y - 15}px`;
      this.tooltip.innerHTML = `
        <div class="font-bold text-indigo-400 capitalize">${this.hoveredNode.type}: ${this.hoveredNode.label}</div>
        ${this.hoveredNode.text_preview ? `<div class="text-[10px] text-gray-400 max-w-[240px] mt-1">${this.hoveredNode.text_preview}</div>` : ''}
      `;
    } else if (this.tooltip) {
      this.tooltip.classList.add('hidden');
    }
  }

  handleMouseDown(e) {
    if (this.hoveredNode) {
      this.isDragging = true;
      this.draggedNode = this.hoveredNode;
    }
  }

  handleMouseUp() {
    this.isDragging = false;
    this.draggedNode = null;
  }
}

window.knowledgeGraphController = new KnowledgeGraphController();
