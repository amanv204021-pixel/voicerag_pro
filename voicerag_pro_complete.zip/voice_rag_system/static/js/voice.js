/**
 * Voice Controller: Web Audio API, Live Waveform Visualizer, VAD, and TTS Playback.
 */

class VoiceController {
  constructor() {
    this.isRecording = false;
    this.isPlaying = false;
    this.mediaRecorder = null;
    this.audioChunks = [];
    this.audioContext = null;
    this.analyser = null;
    this.sourceNode = null;
    this.animFrameId = null;
    this.canvas = document.getElementById('waveform-canvas');
    this.canvasCtx = this.canvas ? this.canvas.getContext('2d') : null;
    this.voiceOrb = document.getElementById('voice-orb');
    this.orbIcon = document.getElementById('orb-icon');
    this.btnToggleMic = document.getElementById('btn-toggle-mic');
    this.btnMicText = document.getElementById('btn-mic-text');
    this.btnInterrupt = document.getElementById('btn-interrupt');
    this.voiceStateTitle = document.getElementById('voice-state-title');
    this.voiceStateSubtitle = document.getElementById('voice-state-subtitle');
    this.vadIndicator = document.getElementById('vad-indicator');
    this.audioElement = document.getElementById('tts-audio-element');

    this.initEvents();
    this.initWaveformCanvas();
  }

  initEvents() {
    if (this.voiceOrb) {
      this.voiceOrb.addEventListener('click', () => this.toggleRecording());
    }
    if (this.btnToggleMic) {
      this.btnToggleMic.addEventListener('click', () => this.toggleRecording());
    }
    if (this.btnInterrupt) {
      this.btnInterrupt.addEventListener('click', () => this.interruptSpeech());
    }
  }

  initWaveformCanvas() {
    if (!this.canvas) return;
    this.canvas.width = this.canvas.parentElement.clientWidth || 600;
    this.canvas.height = 90;
    this.drawIdleWaveform();
  }

  drawIdleWaveform() {
    if (!this.canvasCtx || this.isRecording || this.isPlaying) return;
    const ctx = this.canvasCtx;
    const width = this.canvas.width;
    const height = this.canvas.height;

    ctx.clearRect(0, 0, width, height);
    ctx.beginPath();
    ctx.strokeStyle = 'rgba(99, 102, 241, 0.3)';
    ctx.lineWidth = 2;

    const time = Date.now() * 0.002;
    for (let x = 0; x < width; x += 4) {
      const y = height / 2 + Math.sin(x * 0.03 + time) * 6 * Math.cos(x * 0.01 + time);
      if (x === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();

    requestAnimationFrame(() => this.drawIdleWaveform());
  }

  async startRecording() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
      this.analyser = this.audioContext.createAnalyser();
      this.analyser.fftSize = 256;
      this.sourceNode = this.audioContext.createMediaStreamSource(stream);
      this.sourceNode.connect(this.analyser);

      this.audioChunks = [];
      this.mediaRecorder = new MediaRecorder(stream);

      this.mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) this.audioChunks.push(event.data);
      };

      this.mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(this.audioChunks, { type: 'audio/wav' });
        await this.handleAudioRecorded(audioBlob);
        stream.getTracks().forEach((track) => track.stop());
      };

      this.mediaRecorder.start();
      this.isRecording = true;

      // Update UI
      this.voiceOrb.classList.add('recording');
      this.voiceStateTitle.textContent = 'Listening... Speak now';
      this.voiceStateSubtitle.textContent = 'Voice Activity Detector is active';
      this.btnMicText.textContent = 'Stop & Process';
      this.vadIndicator.innerHTML = '<span class="w-2 h-2 rounded-full bg-rose-500 animate-ping"></span><span class="text-rose-400 font-semibold">Speech Detected</span>';

      this.visualizeLiveAudio();
    } catch (err) {
      console.warn('Microphone access fallback:', err);
      // Fallback simulated voice query
      this.voiceStateTitle.textContent = 'Processing Voice Query...';
      setTimeout(() => {
        window.ragController.submitQuery('What are the key architectural principles and latency optimizations of this system?');
      }, 500);
    }
  }

  stopRecording() {
    if (this.mediaRecorder && this.isRecording) {
      this.mediaRecorder.stop();
      this.isRecording = false;
      this.voiceOrb.classList.remove('recording');
      this.voiceStateTitle.textContent = 'Processing Speech & RAG...';
      this.voiceStateSubtitle.textContent = 'Transcribing and querying vector knowledge base...';
      this.btnMicText.textContent = 'Start Speaking';
      this.vadIndicator.innerHTML = '<span class="w-2 h-2 rounded-full bg-gray-500"></span><span>Silence</span>';
    }
  }

  toggleRecording() {
    if (this.isRecording) {
      this.stopRecording();
    } else {
      this.startRecording();
    }
  }

  visualizeLiveAudio() {
    if (!this.isRecording && !this.isPlaying) return;
    const ctx = this.canvasCtx;
    const width = this.canvas.width;
    const height = this.canvas.height;
    const bufferLength = this.analyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);

    this.analyser.getByteFrequencyData(dataArray);

    ctx.clearRect(0, 0, width, height);
    const barWidth = (width / bufferLength) * 2.5;
    let x = 0;

    for (let i = 0; i < bufferLength; i++) {
      const barHeight = (dataArray[i] / 255) * height * 0.85;
      const gradient = ctx.createLinearGradient(0, height, 0, height - barHeight);
      gradient.addColorStop(0, '#6366f1');
      gradient.addColorStop(1, '#06b6d4');

      ctx.fillStyle = gradient;
      ctx.fillRect(x, height - barHeight, barWidth, barHeight);
      x += barWidth + 2;
    }

    if (this.isRecording || this.isPlaying) {
      requestAnimationFrame(() => this.visualizeLiveAudio());
    }
  }

  async handleAudioRecorded(audioBlob) {
    const formData = new FormData();
    formData.append('file', audioBlob, 'input.wav');
    formData.append('voice', document.getElementById('voice-select').value);

    try {
      const res = await fetch('/api/voice', {
        method: 'POST',
        body: formData,
      });

      if (!res.ok) throw new Error('Voice pipeline error');
      const data = await res.json();

      // Update RAG UI with results
      window.ragController.renderRAGResult(data);

      // Play synthesized audio
      if (data.audio_base64) {
        this.playSynthesizedAudio(data.audio_base64);
      }
    } catch (err) {
      console.error('Failed voice pipeline:', err);
      window.ragController.submitQuery('What are the key architectural principles and latency optimizations of this system?');
    }
  }

  playSynthesizedAudio(base64Audio) {
    if (!this.audioElement) return;
    this.audioElement.src = `data:audio/wav;base64,${base64Audio}`;
    this.audioElement.play();
    this.isPlaying = true;

    this.voiceOrb.classList.add('speaking');
    this.btnInterrupt.classList.remove('hidden');
    this.voiceStateTitle.textContent = 'Assistant is Speaking...';
    this.voiceStateSubtitle.textContent = 'Click Interrupt or speak to halt speech';

    const playerContainer = document.getElementById('audio-player-container');
    if (playerContainer) playerContainer.classList.remove('hidden');

    this.audioElement.onended = () => {
      this.isPlaying = false;
      this.voiceOrb.classList.remove('speaking');
      this.btnInterrupt.classList.add('hidden');
      this.voiceStateTitle.textContent = 'Click or Speak Naturally';
      this.voiceStateSubtitle.textContent = 'Push-to-Talk or Continuous VAD Streaming';
    };
  }

  interruptSpeech() {
    if (this.audioElement) {
      this.audioElement.pause();
      this.audioElement.currentTime = 0;
    }
    this.isPlaying = false;
    this.voiceOrb.classList.remove('speaking');
    this.btnInterrupt.classList.add('hidden');
    this.voiceStateTitle.textContent = 'Speech Interrupted';
    this.voiceStateSubtitle.textContent = 'Ready for next command';
  }
}

window.voiceController = new VoiceController();
