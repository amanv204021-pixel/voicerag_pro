/**
 * Document Ingestion & Knowledge Base Studio Controller.
 */

class DocumentsController {
  constructor() {
    this.dropzone = document.getElementById('dropzone');
    this.fileInput = document.getElementById('file-input');
    this.btnProcess = document.getElementById('btn-process-upload');
    this.strategySelect = document.getElementById('chunk-strategy-select');
    this.docsTableBody = document.getElementById('docs-table-body');
    this.totalDocsBadge = document.getElementById('total-docs-count-badge');
    this.healthChunksCount = document.getElementById('health-chunks-count');
    this.selectedFiles = [];

    this.initEvents();
    this.loadDocuments();
  }

  initEvents() {
    if (this.dropzone) {
      this.dropzone.addEventListener('click', () => this.fileInput.click());
      this.dropzone.addEventListener('dragover', (e) => {
        e.preventDefault();
        this.dropzone.classList.add('border-indigo-500', 'bg-indigo-950/20');
      });
      this.dropzone.addEventListener('dragleave', () => {
        this.dropzone.classList.remove('border-indigo-500', 'bg-indigo-950/20');
      });
      this.dropzone.addEventListener('drop', (e) => {
        e.preventDefault();
        this.dropzone.classList.remove('border-indigo-500', 'bg-indigo-950/20');
        if (e.dataTransfer.files.length) {
          this.handleFilesSelected(Array.from(e.dataTransfer.files));
        }
      });
    }

    if (this.fileInput) {
      this.fileInput.addEventListener('change', (e) => {
        if (e.target.files.length) {
          this.handleFilesSelected(Array.from(e.target.files));
        }
      });
    }

    if (this.btnProcess) {
      this.btnProcess.addEventListener('click', () => this.uploadSelectedFiles());
    }
  }

  handleFilesSelected(files) {
    this.selectedFiles = files;
    this.dropzone.innerHTML = `
      <div class="w-12 h-12 mx-auto rounded-full bg-emerald-600/20 flex items-center justify-center text-emerald-400">
        <i data-lucide="check-circle" class="w-6 h-6"></i>
      </div>
      <div class="text-sm font-semibold text-emerald-400">${files.length} file(s) selected</div>
      <p class="text-xs text-gray-400 font-mono">${files.map((f) => f.name).join(', ')}</p>
    `;
    if (window.lucide) window.lucide.createIcons();
  }

  async uploadSelectedFiles() {
    if (!this.selectedFiles || this.selectedFiles.length === 0) {
      alert('Please select or drop documents first.');
      return;
    }

    const strategy = this.strategySelect ? this.strategySelect.value : 'auto';
    const formData = new FormData();
    for (const f of this.selectedFiles) {
      formData.append('files', f);
    }
    formData.append('strategy', strategy);

    this.btnProcess.innerHTML = `<span class="animate-spin">⏳</span> Indexing Vectors & Lexical Inverted Index...`;
    this.btnProcess.disabled = true;

    try {
      const res = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });

      if (!res.ok) throw new Error('Upload failed');
      const data = await res.json();

      this.selectedFiles = [];
      this.dropzone.innerHTML = `
        <div class="w-12 h-12 mx-auto rounded-full bg-indigo-600/20 flex items-center justify-center text-indigo-400">
          <i data-lucide="file-up" class="w-6 h-6"></i>
        </div>
        <div>
          <span class="text-sm font-semibold text-gray-200">Click to upload</span>
          <span class="text-xs text-gray-400"> or drag and drop</span>
        </div>
        <p class="text-[11px] text-gray-500">PDF, DOCX, TXT, MD, CSV, HTML</p>
      `;

      await this.loadDocuments();
      if (window.knowledgeGraphController) {
        window.knowledgeGraphController.loadGraph();
      }
    } catch (err) {
      alert('Upload error: ' + err.message);
    } finally {
      this.btnProcess.innerHTML = `<i data-lucide="play" class="w-3.5 h-3.5"></i><span>Index Selected Files</span>`;
      this.btnProcess.disabled = false;
      if (window.lucide) window.lucide.createIcons();
    }
  }

  async loadDocuments() {
    try {
      const res = await fetch('/api/documents');
      if (!res.ok) return;
      const data = await res.json();
      this.renderDocumentsTable(data.documents || []);

      if (this.totalDocsBadge) {
        this.totalDocsBadge.textContent = `${data.total_documents} Documents`;
      }
      if (this.healthChunksCount) {
        this.healthChunksCount.textContent = `${data.total_documents} docs / ${data.total_chunks} chunks`;
      }
    } catch (err) {
      console.error('Failed to load docs:', err);
    }
  }

  renderDocumentsTable(docs) {
    if (!this.docsTableBody) return;

    if (docs.length === 0) {
      this.docsTableBody.innerHTML = `
        <tr>
          <td colspan="6" class="text-center py-8 text-gray-500 italic">No indexed documents found. Upload above.</td>
        </tr>
      `;
      return;
    }

    this.docsTableBody.innerHTML = docs
      .map((doc) => {
        return `
        <tr class="hover:bg-gray-800/40 transition">
          <td class="py-3 px-3">
            <div class="font-semibold text-gray-200">${doc.title || doc.filename}</div>
            <div class="text-[10px] text-gray-500 font-mono">${doc.filename}</div>
          </td>
          <td class="py-3 px-2">
            <span class="badge-pill badge-indigo text-[10px] uppercase font-mono">${doc.file_type}</span>
          </td>
          <td class="py-3 px-2 font-mono text-cyan-400 font-semibold">${doc.chunk_count}</td>
          <td class="py-3 px-2 font-mono text-gray-400">${doc.total_tokens}</td>
          <td class="py-3 px-2">
            <span class="badge-pill badge-cyan text-[10px]">${doc.strategy}</span>
          </td>
          <td class="py-3 px-2 text-right">
            <button onclick="window.documentsController.deleteDoc('${doc.doc_id}')" class="p-1.5 rounded-lg bg-rose-600/20 hover:bg-rose-600/40 text-rose-300 transition" title="Delete Document">
              <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
            </button>
          </td>
        </tr>
      `;
      })
      .join('');

    if (window.lucide) window.lucide.createIcons();
  }

  async deleteDoc(docId) {
    if (!confirm('Are you sure you want to remove this document and all its indexed vectors?')) return;
    try {
      const res = await fetch(`/api/documents/${docId}`, { method: 'DELETE' });
      if (!res.ok) throw new Error('Delete failed');
      await this.loadDocuments();
      if (window.knowledgeGraphController) {
        window.knowledgeGraphController.loadGraph();
      }
    } catch (e) {
      alert('Delete error: ' + e.message);
    }
  }
}

window.documentsController = new DocumentsController();
