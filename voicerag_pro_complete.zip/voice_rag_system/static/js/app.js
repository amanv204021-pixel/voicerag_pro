/**
 * Main Web App Orchestrator: Navigation, Tabs, Lucide Icons, and Lifecycle Events.
 */

document.addEventListener('DOMContentLoaded', () => {
  // Initialize Lucide Icons
  if (window.lucide) {
    window.lucide.createIcons();
  }

  // Setup Navigation Tabs
  const navTabs = document.querySelectorAll('.nav-tab');
  const tabPanes = document.querySelectorAll('.tab-pane');

  navTabs.forEach((tab) => {
    tab.addEventListener('click', () => {
      const targetId = tab.getAttribute('data-tab');

      navTabs.forEach((t) => t.classList.remove('active'));
      tabPanes.forEach((p) => p.classList.add('hidden'));

      tab.classList.add('active');
      const targetPane = document.getElementById(targetId);
      if (targetPane) {
        targetPane.classList.remove('hidden');
      }

      // If Knowledge Graph tab selected, trigger graph reload/resize
      if (targetId === 'graph-tab' && window.knowledgeGraphController) {
        window.knowledgeGraphController.loadGraph();
      }

      // Re-render icons on tab switch
      if (window.lucide) {
        window.lucide.createIcons();
      }
    });
  });

  // Health check polling
  async function checkHealth() {
    try {
      const res = await fetch('/health');
      if (res.ok) {
        const data = await res.json();
        const chunksCountEl = document.getElementById('health-chunks-count');
        if (chunksCountEl && data.vector_store) {
          chunksCountEl.textContent = `${data.vector_store.indexed_chunks} indexed chunks`;
        }
      }
    } catch (e) {
      console.log('Health check notice:', e);
    }
  }

  setInterval(checkHealth, 15000);
  checkHealth();
});
