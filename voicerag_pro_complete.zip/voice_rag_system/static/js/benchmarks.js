/**
 * Benchmarks, Latency Profiler, and Security Guardrails Controller.
 */

class BenchmarksController {
  constructor() {
    this.btnRunLiveBench = document.getElementById('btn-run-live-bench');
    this.embeddingTbody = document.getElementById('embedding-bench-tbody');
    this.latencyStagesContainer = document.getElementById('latency-stages-container');
    this.p50Val = document.getElementById('bench-p50-val');
    this.p99Val = document.getElementById('bench-p99-val');
    this.recallVal = document.getElementById('bench-recall-val');
    this.groundingVal = document.getElementById('bench-grounding-val');

    // Guardrails Sandbox elements
    this.guardrailsInput = document.getElementById('guardrails-input');
    this.btnInspectGuardrails = document.getElementById('btn-inspect-guardrail');
    this.guardrailsOutput = document.getElementById('guardrails-output');

    this.initEvents();
    this.loadBenchmarkOverview();
  }

  initEvents() {
    if (this.btnRunLiveBench) {
      this.btnRunLiveBench.addEventListener('click', () => this.runLiveBenchmark());
    }

    if (this.btnInspectGuardrails) {
      this.btnInspectGuardrails.addEventListener('click', () => this.inspectGuardrails());
    }
  }

  async loadBenchmarkOverview() {
    try {
      const res = await fetch('/api/benchmark');
      if (!res.ok) return;
      const data = await res.json();

      this.renderEmbeddingTable(data.embedding_benchmark);
      this.renderLatencyStages(data.latency_profile);
    } catch (err) {
      console.error('Failed to load benchmark overview:', err);
    }
  }

  renderEmbeddingTable(benchData) {
    if (!this.embeddingTbody || !benchData || !benchData.models) return;

    this.embeddingTbody.innerHTML = benchData.models
      .map((m) => {
        const isSelected = m.model_name === benchData.selected_model;
        return `
        <tr class="${isSelected ? 'bg-indigo-950/30 font-medium' : 'hover:bg-gray-800/40'} transition">
          <td class="py-3 px-3">
            <div class="flex items-center gap-2">
              <span class="font-mono text-gray-100">${m.model_name}</span>
              ${isSelected ? '<span class="badge-pill badge-emerald text-[9px]">ACTIVE DEFAULT</span>' : ''}
            </div>
          </td>
          <td class="py-3 px-2 text-gray-400">${m.provider}</td>
          <td class="py-3 px-2 font-mono text-gray-300">${m.dimension}</td>
          <td class="py-3 px-2 font-mono text-emerald-400 font-semibold">${(m.recall_at_5 * 100).toFixed(1)}%</td>
          <td class="py-3 px-2 font-mono text-indigo-300">${m.mrr.toFixed(3)}</td>
          <td class="py-3 px-2 font-mono text-cyan-400">${m.latency_p50_ms.toFixed(1)} ms</td>
          <td class="py-3 px-2 font-mono text-amber-300">$${m.cost_per_1m_tokens_usd.toFixed(2)}</td>
          <td class="py-3 px-2">
            <span class="badge-pill ${isSelected ? 'badge-emerald' : 'badge-indigo'} text-[10px]">
              ${m.recommendation}
            </span>
          </td>
        </tr>
      `;
      })
      .join('');
  }

  renderLatencyStages(profileData) {
    if (!this.latencyStagesContainer || !profileData) return;

    const e2e = profileData.e2e_latency_ms || {};
    if (this.p50Val && e2e.p50) this.p50Val.textContent = `${e2e.p50} ms`;
    if (this.p99Val && e2e.p99) this.p99Val.textContent = `${e2e.p99} ms`;

    const stages = profileData.stages_breakdown_ms || {};
    const stageNames = {
      vad_and_stt: 'Streaming VAD & Faster-Whisper STT',
      guardrails: 'Pre-flight Multi-Layer Security Guardrails',
      query_expansion: 'HyDE & Multi-Query Expansion',
      dense_vector_search: 'Dense Vector Search (Normalized Matrix)',
      bm25_sparse_search: 'BM25 Keyword Sparse Inverted Search',
      rrf_hybrid_fusion: 'Reciprocal Rank Fusion (RRF)',
      cross_encoder_rerank: 'Cross-Encoder Neural Reranking & MMR',
      context_compression: 'Extractive Sentence Context Compression',
      llm_time_to_first_token: 'LLM Time-to-First-Token (TTFT)',
      llm_generation_total: 'Full Grounded LLM Response Streaming',
      tts_streaming_audio: 'Streaming Text-to-Speech Waveform Synthesis',
    };

    let html = '';
    for (const [key, label] of Object.entries(stageNames)) {
      const stats = stages[key] || { p50: 10, p95: 20, p99: 25 };
      const maxLimit = 500;
      const barPct = Math.min(100, Math.max(5, (stats.p50 / maxLimit) * 100));

      html += `
        <div class="space-y-1 text-xs">
          <div class="flex items-center justify-between text-gray-300">
            <span class="font-medium">${label}</span>
            <div class="flex items-center gap-3 font-mono text-[11px]">
              <span class="text-emerald-400">P50: ${stats.p50}ms</span>
              <span class="text-cyan-400">P95: ${stats.p95}ms</span>
              <span class="text-indigo-400">P99: ${stats.p99}ms</span>
            </div>
          </div>
          <div class="meter-container">
            <div class="meter-fill bg-gradient-to-r from-emerald-500 via-cyan-500 to-indigo-500" style="width: ${barPct}%"></div>
          </div>
        </div>
      `;
    }

    this.latencyStagesContainer.innerHTML = html;
  }

  async runLiveBenchmark() {
    this.btnRunLiveBench.innerHTML = `<span class="animate-spin">⏳</span> Running IR Benchmark Suite...`;
    this.btnRunLiveBench.disabled = true;

    try {
      const res = await fetch('/api/benchmark/run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({}),
      });

      if (!res.ok) throw new Error('Benchmark failed');
      const data = await res.json();

      if (data.retrieval_metrics && this.recallVal) {
        this.recallVal.textContent = `${(data.retrieval_metrics.recall_at_5 * 100).toFixed(1)}%`;
      }
      this.renderLatencyStages(data.latency_profile);
      alert('Live evaluation benchmark completed successfully! Check updated metrics.');
    } catch (err) {
      alert('Benchmark error: ' + err.message);
    } finally {
      this.btnRunLiveBench.innerHTML = `<i data-lucide="play-circle" class="w-4 h-4"></i><span>Run Live Benchmark</span>`;
      this.btnRunLiveBench.disabled = false;
      if (window.lucide) window.lucide.createIcons();
    }
  }

  async inspectGuardrails() {
    const text = this.guardrailsInput.value.trim();
    if (!text) {
      alert('Please enter a query or attack payload to inspect.');
      return;
    }

    this.btnInspectGuardrails.innerHTML = `<span class="animate-spin">⏳</span> Scanning...`;
    try {
      const res = await fetch('/api/guardrails/inspect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: text }),
      });

      const result = await res.json();

      const verdictClass = result.is_safe ? 'text-emerald-400' : 'text-rose-400';
      const actionBadge = result.action === 'allow' ? 'badge-emerald' : result.action === 'mask' ? 'badge-cyan' : 'badge-rose';

      this.guardrailsOutput.innerHTML = `
        <div class="flex items-center justify-between pb-2 border-b border-white/10">
          <span class="font-bold ${verdictClass}">Verdict: ${result.is_safe ? 'SAFE / ALLOWED' : 'BLOCKED / ADVERSARIAL'}</span>
          <span class="badge-pill ${actionBadge} uppercase">${result.action}</span>
        </div>
        <div><strong>Prompt Injection Score:</strong> <span class="font-mono text-cyan-400">${(result.prompt_injection_score * 100).toFixed(0)}%</span></div>
        <div><strong>Toxicity Score:</strong> <span class="font-mono text-amber-400">${(result.toxicity_score * 100).toFixed(0)}%</span></div>
        <div><strong>Detected PII:</strong> ${result.masked_pii_entities && result.masked_pii_entities.length ? `<span class="text-rose-300">${result.masked_pii_entities.join(', ')}</span>` : '<span class="text-gray-500">None</span>'}</div>
        <div><strong>Sanitized Text:</strong> <span class="text-gray-100 italic">"${result.sanitized_text}"</span></div>
        ${result.reasons && result.reasons.length ? `<div class="pt-2 text-[11px] text-gray-400"><strong>Reasons:</strong><ul class="list-disc pl-4">${result.reasons.map((r) => `<li>${r}</li>`).join('')}</ul></div>` : ''}
      `;
    } catch (err) {
      this.guardrailsOutput.innerHTML = `<div class="text-rose-400">Error: ${err.message}</div>`;
    } finally {
      this.btnInspectGuardrails.innerHTML = `<i data-lucide="shield-check" class="w-4 h-4"></i><span>Evaluate Security Policies</span>`;
      if (window.lucide) window.lucide.createIcons();
    }
  }
}

window.benchmarksController = new BenchmarksController();
