"""
Configuration Module for Voice-Enabled Production RAG System.
Handles environment-driven settings with Pydantic validation.
"""

from typing import List, Optional
import os
from pydantic import BaseModel, Field


class Settings(BaseModel):
    # Application Info
    APP_NAME: str = "VoiceRAG-Pro"
    APP_VERSION: str = "1.0.0"
    ENVIRONMENT: str = "production"
    DEBUG: bool = False
    HOST: str = "0.0.0.0"
    PORT: int = 8000

    # Storage Paths
    BASE_DIR: str = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    UPLOAD_DIR: str = os.path.join(BASE_DIR, "data", "uploads")
    VECTOR_DB_DIR: str = os.path.join(BASE_DIR, "data", "vector_db")

    # Embedding Models & Specs
    DEFAULT_EMBEDDING_MODEL: str = "BAAI/bge-large-en-v1.5"
    EMBEDDING_DIMENSION: int = 1024
    AVAILABLE_EMBEDDING_MODELS: List[str] = [
        "BAAI/bge-large-en-v1.5",
        "intfloat/e5-large-v2",
        "jinaai/jina-embeddings-v2-base-en",
        "nomic-ai/nomic-embed-text-v1.5",
        "text-embedding-3-large",
    ]

    # Vector Database & Retrieval
    VECTOR_STORE_TYPE: str = "in-memory"  # 'in-memory' or 'qdrant'
    QDRANT_HOST: Optional[str] = None
    QDRANT_PORT: int = 6333
    SIMILARITY_METRIC: str = "cosine"  # 'cosine', 'dot_product', 'euclidean'
    
    # BM25 Lexical Search Parameters
    BM25_K1: float = 1.5
    BM25_B: float = 0.75

    # Hybrid Search & RRF Parameters
    HYBRID_RRF_K: int = 60
    HYBRID_DENSE_WEIGHT: float = 0.65
    HYBRID_SPARSE_WEIGHT: float = 0.35
    RETRIEVAL_TOP_CANDIDATES: int = 25
    FINAL_TOP_K: int = 5

    # Reranker & Context Compression
    RERANKER_MODEL: str = "cross-encoder/ms-marco-MiniLM-L-6-v2"
    ENABLE_RERANKING: bool = True
    ENABLE_CONTEXT_COMPRESSION: bool = True
    COMPRESSION_RATIO: float = 0.65  # Target retention ratio for extractive compression
    MMR_LAMBDA: float = 0.7  # Relevance vs Diversity trade-off

    # Chunking Defaults
    DEFAULT_CHUNKER_STRATEGY: str = "auto"  # 'auto', 'semantic', 'parent_child', 'recursive', 'sliding', 'sentence'
    CHUNK_SIZE: int = 512
    CHUNK_OVERLAP: int = 64
    PARENT_CHUNK_SIZE: int = 1024
    CHILD_CHUNK_SIZE: int = 256

    # LLM Settings
    LLM_MODEL: str = "gpt-5"
    LLM_TEMPERATURE: float = 0.1
    LLM_MAX_TOKENS: int = 1024
    GROUNDING_STRICTNESS: str = "strict"  # 'strict', 'moderate', 'permissive'
    REFUSAL_MESSAGE: str = (
        "I cannot answer this question based solely on the provided context documents. "
        "No verified supporting evidence was found in the indexed knowledge base."
    )

    # Guardrails & Security
    ENABLE_PROMPT_INJECTION_DETECTION: bool = True
    ENABLE_PII_MASKING: bool = True
    ENABLE_TOXICITY_FILTER: bool = True
    INJECTION_CONFIDENCE_THRESHOLD: float = 0.75
    TOXICITY_THRESHOLD: float = 0.70

    # Voice Engine (STT & TTS)
    AUDIO_SAMPLE_RATE: int = 16000
    VAD_ENERGY_THRESHOLD: float = 0.015
    VAD_SPEECH_PAD_MS: int = 300
    STT_MODEL: str = "faster-whisper-large-v3"
    DEFAULT_VOICE_LANGUAGE: str = "en"
    TTS_DEFAULT_VOICE: str = "alloy"
    TTS_DEFAULT_SPEED: float = 1.05

    # Cache & Performance
    ENABLE_CACHE: bool = True
    CACHE_TTL_SECONDS: int = 3600
    MAX_CACHE_ITEMS: int = 10000

    # Telemetry & Resilience
    CIRCUIT_BREAKER_FAILURE_THRESHOLD: int = 5
    CIRCUIT_BREAKER_RECOVERY_TIMEOUT_SEC: float = 30.0
    REQUEST_TIMEOUT_SEC: float = 25.0


settings = Settings()
