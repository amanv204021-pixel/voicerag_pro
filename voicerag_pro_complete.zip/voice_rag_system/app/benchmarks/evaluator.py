"""
Retrieval & Grounding Accuracy Evaluation Engine.
Computes Recall@K, Precision@K, Mean Reciprocal Rank (MRR), MAP, and NDCG@K.
"""

import math
from typing import Any, Dict, List, Set


class RetrievalEvaluator:
    """
    Standard Information Retrieval (IR) evaluation metrics suite.
    """

    @staticmethod
    def precision_at_k(retrieved_ids: List[str], ground_truth_ids: Set[str], k: int) -> float:
        """Calculate Precision@K."""
        if k <= 0 or not retrieved_ids:
            return 0.0
        k_items = retrieved_ids[:k]
        relevant_retrieved = sum(1 for item_id in k_items if item_id in ground_truth_ids)
        return relevant_retrieved / k

    @staticmethod
    def recall_at_k(retrieved_ids: List[str], ground_truth_ids: Set[str], k: int) -> float:
        """Calculate Recall@K."""
        if not ground_truth_ids or not retrieved_ids:
            return 0.0
        k_items = retrieved_ids[:k]
        relevant_retrieved = sum(1 for item_id in k_items if item_id in ground_truth_ids)
        return relevant_retrieved / len(ground_truth_ids)

    @staticmethod
    def mean_reciprocal_rank(retrieved_ids: List[str], ground_truth_ids: Set[str]) -> float:
        """Calculate Mean Reciprocal Rank (MRR)."""
        for rank, item_id in enumerate(retrieved_ids, start=1):
            if item_id in ground_truth_ids:
                return 1.0 / rank
        return 0.0

    @staticmethod
    def ndcg_at_k(retrieved_ids: List[str], ground_truth_ids: Set[str], k: int) -> float:
        """Calculate Normalized Discounted Cumulative Gain (NDCG@K)."""
        if not ground_truth_ids or not retrieved_ids:
            return 0.0

        k_items = retrieved_ids[:k]
        dcg = 0.0
        for rank, item_id in enumerate(k_items, start=1):
            rel = 1.0 if item_id in ground_truth_ids else 0.0
            dcg += rel / math.log2(rank + 1)

        # Ideal DCG
        idcg = sum(1.0 / math.log2(i + 1) for i in range(1, min(k, len(ground_truth_ids)) + 1))
        if idcg < 1e-9:
            return 0.0
        return dcg / idcg

    @classmethod
    def evaluate_benchmark_suite(
        cls,
        eval_cases: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """
        Evaluate full benchmark suite over multiple queries.
        eval_cases: List of {'retrieved_ids': [...], 'ground_truth_ids': set(...)}
        """
        if not eval_cases:
            return {
                "recall_at_1": 0.0,
                "recall_at_3": 0.0,
                "recall_at_5": 0.0,
                "precision_at_1": 0.0,
                "precision_at_3": 0.0,
                "precision_at_5": 0.0,
                "mrr": 0.0,
                "ndcg_at_5": 0.0,
                "total_eval_queries": 0,
            }

        recalls_1, recalls_3, recalls_5 = [], [], []
        precisions_1, precisions_3, precisions_5 = [], [], []
        mrrs, ndcgs_5 = [], []

        for case in eval_cases:
            ret = case.get("retrieved_ids", [])
            gt = set(case.get("ground_truth_ids", []))

            recalls_1.append(cls.recall_at_k(ret, gt, 1))
            recalls_3.append(cls.recall_at_k(ret, gt, 3))
            recalls_5.append(cls.recall_at_k(ret, gt, 5))

            precisions_1.append(cls.precision_at_k(ret, gt, 1))
            precisions_3.append(cls.precision_at_k(ret, gt, 3))
            precisions_5.append(cls.precision_at_k(ret, gt, 5))

            mrrs.append(cls.mean_reciprocal_rank(ret, gt))
            ndcgs_5.append(cls.ndcg_at_k(ret, gt, 5))

        return {
            "recall_at_1": round(sum(recalls_1) / len(recalls_1), 4),
            "recall_at_3": round(sum(recalls_3) / len(recalls_3), 4),
            "recall_at_5": round(sum(recalls_5) / len(recalls_5), 4),
            "precision_at_1": round(sum(precisions_1) / len(precisions_1), 4),
            "precision_at_3": round(sum(precisions_3) / len(precisions_3), 4),
            "precision_at_5": round(sum(precisions_5) / len(precisions_5), 4),
            "mrr": round(sum(mrrs) / len(mrrs), 4),
            "ndcg_at_5": round(sum(ndcgs_5) / len(ndcgs_5), 4),
            "total_eval_queries": len(eval_cases),
        }


retrieval_evaluator = RetrievalEvaluator()
