"""
Voice Activity Detection (VAD) and Audio Noise Suppression Engine.
Calculates frame energy, zero-crossing rate, and spectral density to detect human speech boundaries.
"""

import math
import numpy as np
from typing import List, Tuple
from app.config import settings
from app.core.logging import logger


class VoiceActivityDetector:
    """
    Real-time energy and zero-crossing rate Voice Activity Detector.
    """

    def __init__(
        self,
        sample_rate: int = settings.AUDIO_SAMPLE_RATE,
        frame_duration_ms: int = 30,
        energy_threshold: float = settings.VAD_ENERGY_THRESHOLD,
    ):
        self.sample_rate = sample_rate
        self.frame_size = int(sample_rate * (frame_duration_ms / 1000.0))
        self.energy_threshold = energy_threshold

    def calculate_frame_energy(self, frame: np.ndarray) -> float:
        """Compute root-mean-square (RMS) energy of an audio frame."""
        if len(frame) == 0:
            return 0.0
        return float(np.sqrt(np.mean(frame.astype(np.float32) ** 2)))

    def calculate_zcr(self, frame: np.ndarray) -> float:
        """Calculate Zero-Crossing Rate (ZCR) for unvoiced/voiced speech distinction."""
        if len(frame) < 2:
            return 0.0
        zero_crossings = np.sum(np.abs(np.diff(np.sign(frame)))) / 2
        return float(zero_crossings / len(frame))

    def suppress_noise(self, audio_data: np.ndarray, alpha: float = 0.95) -> np.ndarray:
        """Apply high-pass pre-emphasis filter to suppress low-frequency background hum."""
        if len(audio_data) < 2:
            return audio_data
        filtered = np.zeros_like(audio_data, dtype=np.float32)
        filtered[0] = audio_data[0]
        filtered[1:] = audio_data[1:] - alpha * audio_data[:-1]
        return filtered

    def detect_speech_segments(
        self,
        audio_samples: np.ndarray,
    ) -> Tuple[bool, float, List[Tuple[int, int]]]:
        """
        Scan audio samples and return:
        (contains_speech, average_energy, speech_intervals_in_frames)
        """
        if len(audio_samples) == 0:
            return False, 0.0, []

        clean_samples = self.suppress_noise(audio_samples)
        num_frames = len(clean_samples) // self.frame_size

        speech_frames: List[int] = []
        energies: List[float] = []

        for i in range(num_frames):
            frame = clean_samples[i * self.frame_size : (i + 1) * self.frame_size]
            energy = self.calculate_frame_energy(frame)
            zcr = self.calculate_zcr(frame)
            energies.append(energy)

            # Speech detected if energy exceeds threshold and ZCR is within speech frequency band
            if energy > self.energy_threshold and zcr > 0.02:
                speech_frames.append(i)

        avg_energy = float(np.mean(energies)) if energies else 0.0
        has_speech = len(speech_frames) >= 2

        # Group consecutive speech frames into intervals
        intervals: List[Tuple[int, int]] = []
        if speech_frames:
            start_f = speech_frames[0]
            prev_f = speech_frames[0]
            for f in speech_frames[1:]:
                if f - prev_f <= 2:  # allow 1 frame pause
                    prev_f = f
                else:
                    intervals.append((start_f * self.frame_size, (prev_f + 1) * self.frame_size))
                    start_f = f
                    prev_f = f
            intervals.append((start_f * self.frame_size, (prev_f + 1) * self.frame_size))

        return has_speech, round(avg_energy, 4), intervals


vad_detector = VoiceActivityDetector()
