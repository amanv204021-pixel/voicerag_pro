"""
Knowledge Graph Visualization API Route.
"""

from typing import Any, Dict
from fastapi import APIRouter
from app.retrieval.graph import knowledge_graph_engine

router = APIRouter(prefix="/api/graph", tags=["Knowledge Graph"])


@router.get("")
async def get_knowledge_graph() -> Dict[str, Any]:
    """
    Retrieve node-link graph data structure representing indexed documents, sections, and entities.
    """
    return knowledge_graph_engine.build_graph()
