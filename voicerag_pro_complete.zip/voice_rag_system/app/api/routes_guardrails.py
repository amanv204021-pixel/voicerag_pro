"""
Security & Guardrails Inspection Sandbox API.
"""

from typing import Any, Dict
from fastapi import APIRouter
from pydantic import BaseModel
from app.core.guardrails import GuardrailCheckResult, guardrails_engine

router = APIRouter(prefix="/api/guardrails", tags=["Guardrails"])


class GuardrailInspectRequest(BaseModel):
    text: str


@router.post("/inspect", response_model=GuardrailCheckResult)
async def inspect_text(request: GuardrailInspectRequest) -> GuardrailCheckResult:
    """
    Run full security inspection suite: prompt injection, jailbreak detection, PII masking, and toxicity analysis.
    """
    return guardrails_engine.evaluate_query(request.text)
