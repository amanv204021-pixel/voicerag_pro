"""
Health Checks, Observability, and Prometheus Telemetry Metrics Routes.
"""

import os
import psutil
import time
from typing import Any, Dict
from fastapi import APIRouter, Response
from app.config import settings
from app.core.cache import cache
from app.core.telemetry import metrics_collector
from app.retrieval.vector_store import vector_store

router = APIRouter(tags=["Observability"])

START_TIME = time.time()


@router.get("/health")
async def health_check() -> Dict[str, Any]:
    """
    Comprehensive multi-system health and readiness check.
    """
    uptime_sec = round(time.time() - START_TIME, 2)
    process = psutil.Process(os.getpid())
    mem_info = process.memory_info()

    return {
        "status": "healthy",
        "app_name": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "environment": settings.ENVIRONMENT,
        "uptime_seconds": uptime_sec,
        "system": {
            "cpu_percent": psutil.cpu_percent(interval=None),
            "memory_used_mb": round(mem_info.rss / (1024 * 1024), 2),
            "threads_count": process.num_threads(),
        },
        "vector_store": {
            "indexed_chunks": len(vector_store.chunks),
            "status": "online",
        },
        "cache": cache.get_stats(),
    }


@router.get("/metrics")
async def get_metrics(format: str = "prometheus") -> Any:
    """
    Telemetry metrics endpoint. Returns Prometheus format by default, or JSON format.
    """
    if format.lower() == "json":
        return {
            "telemetry": metrics_collector.get_latency_report(),
            "cache": cache.get_stats(),
        }
    else:
        prom_text = metrics_collector.get_prometheus_metrics()
        return Response(content=prom_text, media_type="text/plain; version=0.0.4")
