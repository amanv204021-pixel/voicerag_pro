"""
Grounded RAG Pipeline & Streaming Query Endpoints.
"""

from typing import Any, Dict, List, Optional
from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from app.config import settings
from app.core.cache import cache
from app.core.guardrails import guardrails_engine
from app.core.logging import logger
from app.core.telemetry import StageTimer, metrics_collector
from app.document_processing.extractor import DocumentChunk
from app.llm.engine import RAGResponse, llm_engine
from app.retrieval.compressor import context_compressor
from app.retrieval.hybrid import hybrid_search_engine
from app.retrieval.reranker import reranker

router = APIRouter(prefix="/api", tags=["RAG"])


class AskRequest(BaseModel):
    query: str
    top_k: int = 5
    use_multi_query: bool = True
    use_reranker: bool = True
    use_compression: bool = True
    filter_metadata: Optional[Dict[str, Any]] = None


class AskResponse(BaseModel):
    query: str
    answer: str
    thought_process: str
    citations: List[Dict[str, Any]]
    grounding_score: float
    hallucination_risk: str
    retrieved_sources: List[Dict[str, Any]]
    latency_waterfall: Dict[str, Any]
    security_check: Dict[str, Any]
    cached: bool = False


@router.post("/ask", response_model=AskResponse)
async def ask_rag(request: AskRequest) -> AskResponse:
    """
    Execute full grounded RAG query pipeline with multi-stage telemetry.
    """
    timer = StageTimer()

    # Check cache first
    cache_key = cache.generate_key("rag_ask", request.model_dump())
    if settings.ENABLE_CACHE:
        cached_result = cache.get(cache_key)
        if cached_result:
            logger.info(f"Cache hit for query: '{request.query[:30]}'")
            cached_result["cached"] = True
            return AskResponse(**cached_result)

    # 1. Security & Safety Guardrails
    with timer.measure("guardrails"):
        guard_res = guardrails_engine.evaluate_query(request.query)

    if not guard_res.is_safe:
        refusal_resp = AskResponse(
            query=request.query,
            answer=(
                "Security Policy Violation: Your request could not be processed due to safety constraints "
                f"({', '.join(guard_res.reasons)})."
            ),
            thought_process="Request rejected by pre-flight security guardrails.",
            citations=[],
            grounding_score=0.0,
            hallucination_risk="HIGH",
            retrieved_sources=[],
            latency_waterfall=timer.get_summary(),
            security_check=guard_res.model_dump(),
            cached=False,
        )
        metrics_collector.record_request(timer, is_error=True)
        return refusal_resp

    effective_query = guard_res.sanitized_text

    # 2. Hybrid Retrieval (Dense + BM25 + RRF)
    with timer.measure("hybrid_retrieval"):
        hybrid_candidates = hybrid_search_engine.search(
            query=effective_query,
            top_k=settings.RETRIEVAL_TOP_CANDIDATES,
            use_multi_query=request.use_multi_query,
            filter_metadata=request.filter_metadata,
        )

    # 3. Cross-Encoder Neural Reranking & MMR Diversity
    with timer.measure("reranking"):
        if request.use_reranker and hybrid_candidates:
            reranked_items = reranker.rerank(
                query=effective_query,
                candidates=hybrid_candidates,
                top_k=request.top_k,
                apply_mmr=True,
            )
        else:
            reranked_items = [
                {
                    "chunk": c,
                    "score": s,
                    "hybrid_score": s,
                    "original_rank": idx,
                    "final_rank": idx,
                    "rank_shift": 0,
                    "breakdown": bd,
                }
                for idx, (c, s, bd) in enumerate(hybrid_candidates[: request.top_k], start=1)
            ]

    # 4. Context Compression (Sentence-Level Pruning)
    with timer.measure("context_compression"):
        if request.use_compression and reranked_items:
            compressed_items = context_compressor.compress_all(effective_query, reranked_items)
        else:
            compressed_items = reranked_items

    # 5. Grounded LLM Generation with Internal CoT
    with timer.measure("llm_generation"):
        rag_output: RAGResponse = llm_engine.generate_grounded_answer(
            query=effective_query,
            retrieved_items=compressed_items,
        )

    # Prepare detailed retrieved sources for frontend inspection
    formatted_sources = []
    for item in compressed_items:
        chunk: DocumentChunk = item["chunk"]
        formatted_sources.append({
            "chunk_id": chunk.chunk_id,
            "filename": chunk.metadata.get("filename", "Doc"),
            "page": chunk.page,
            "section_title": chunk.section_title,
            "strategy": chunk.strategy,
            "score": round(item.get("score", 0.0), 4),
            "text": chunk.text,
            "compressed_text": item.get("compressed_text", chunk.text),
            "compression_stats": item.get("compression_stats", {}),
            "rank_shift": item.get("rank_shift", 0),
            "breakdown": item.get("breakdown", {}),
        })

    response_data = {
        "query": request.query,
        "answer": rag_output.answer,
        "thought_process": rag_output.thought_process,
        "citations": rag_output.citations,
        "grounding_score": rag_output.grounding_score,
        "hallucination_risk": rag_output.hallucination_risk,
        "retrieved_sources": formatted_sources,
        "latency_waterfall": timer.get_summary(),
        "security_check": guard_res.model_dump(),
        "cached": False,
    }

    # Store in cache
    if settings.ENABLE_CACHE and not rag_output.refused:
        cache.set(cache_key, response_data, ttl_sec=settings.CACHE_TTL_SECONDS)

    metrics_collector.record_request(timer, is_voice=False, is_error=False)
    return AskResponse(**response_data)


@router.get("/ask/stream")
async def ask_rag_stream(
    query: str = Query(..., description="User query string"),
    top_k: int = Query(5, description="Number of source chunks"),
):
    """
    Server-Sent Events (SSE) streaming endpoint for grounded token generation.
    """
    guard_res = guardrails_engine.evaluate_query(query)
    if not guard_res.is_safe:
        async def refusal_stream():
            yield f"event: error\ndata: {guard_res.reasons[0]}\n\n"
        return StreamingResponse(refusal_stream(), media_type="text/event-stream")

    hybrid_candidates = hybrid_search_engine.search(
        query=guard_res.sanitized_text,
        top_k=settings.RETRIEVAL_TOP_CANDIDATES,
    )
    reranked = reranker.rerank(guard_res.sanitized_text, hybrid_candidates, top_k=top_k)
    compressed = context_compressor.compress_all(guard_res.sanitized_text, reranked)

    return StreamingResponse(
        llm_engine.stream_grounded_answer(guard_res.sanitized_text, compressed),
        media_type="text/event-stream",
    )
