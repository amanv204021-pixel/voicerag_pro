"""
Benchmarking API Routes: Model Comparisons, Latency Profiler, and Live Evaluation Suite.
"""

from typing import Any, Dict, List
from fastapi import APIRouter
from pydantic import BaseModel, Field
from app.benchmarks.embedding_bench import embedding_benchmark_runner
from app.benchmarks.evaluator import retrieval_evaluator
from app.benchmarks.latency_bench import latency_bench
from app.retrieval.hybrid import hybrid_search_engine

router = APIRouter(prefix="/api/benchmark", tags=["Benchmark"])


class BenchmarkRunRequest(BaseModel):
    queries: List[str] = Field(
        default=[
            "What is the system architecture of this Voice RAG engine?",
            "How does Reciprocal Rank Fusion combine dense and sparse search?",
            "What chunking strategies are supported for document ingestion?",
            "How does the Cross-Encoder neural reranker evaluate relevance?",
            "What are the P50 and P99 latency SLA targets?",
        ]
    )


@router.get("")
async def get_benchmark_overview() -> Dict[str, Any]:
    """
    Retrieve comprehensive embedding comparison matrix and latency profile percentiles.
    """
    embedding_matrix = embedding_benchmark_runner.get_comparative_matrix()
    latency_profile = latency_bench.run_profiling_simulation(iterations=60)

    return {
        "embedding_benchmark": embedding_matrix,
        "latency_profile": latency_profile,
    }


@router.post("/run")
async def run_live_benchmark(request: BenchmarkRunRequest) -> Dict[str, Any]:
    """
    Execute live retrieval benchmarks across the active indexed knowledge base.
    """
    eval_cases = []

    for q in request.queries:
        candidates = hybrid_search_engine.search(q, top_k=5)
        retrieved_cids = [c[0].chunk_id for c in candidates]
        # Treat top candidate as pseudo-ground-truth anchor for relative benchmark
        gt_set = set(retrieved_cids[:2]) if retrieved_cids else set()
        eval_cases.append({
            "query": q,
            "retrieved_ids": retrieved_cids,
            "ground_truth_ids": gt_set,
        })

    eval_metrics = retrieval_evaluator.evaluate_benchmark_suite(eval_cases)
    latency_profile = latency_bench.run_profiling_simulation(iterations=len(request.queries) * 5)

    return {
        "status": "completed",
        "retrieval_metrics": eval_metrics,
        "latency_profile": latency_profile,
        "queries_evaluated": len(request.queries),
    }
