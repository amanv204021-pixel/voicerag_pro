"""
Voice Pipeline API: Streaming STT, Real-time Speech Transcription, TTS Synthesis, and Voice-to-Voice RAG.
"""

from typing import Any, Dict, Optional
from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from pydantic import BaseModel
from app.config import settings
from app.core.logging import logger
from app.core.telemetry import StageTimer, metrics_collector
from app.api.routes_rag import AskRequest, ask_rag
from app.voice.stt import STTResult, stt_engine
from app.voice.tts import TTSAudioResponse, tts_engine

router = APIRouter(prefix="/api/voice", tags=["Voice"])


class TranscribeResponse(BaseModel):
    transcript: str
    confidence: float
    detected_language: str
    duration_sec: float
    latency_ms: float
    speech_detected: bool


class SynthesizeRequest(BaseModel):
    text: str
    voice: str = settings.TTS_DEFAULT_VOICE
    speed: float = settings.TTS_DEFAULT_SPEED


class VoiceRAGResponse(BaseModel):
    query_transcript: str
    answer_text: str
    thought_process: str
    audio_base64: str
    audio_format: str
    citations: list
    grounding_score: float
    hallucination_risk: str
    retrieved_sources: list
    latency_waterfall: Dict[str, Any]
    detected_language: str


@router.post("/transcribe", response_model=TranscribeResponse)
async def transcribe_audio(
    file: UploadFile = File(...),
    language: Optional[str] = Form(default=None),
) -> TranscribeResponse:
    """
    Transcribe audio stream into text with language detection and confidence scoring.
    """
    audio_bytes = await file.read()
    if not audio_bytes:
        raise HTTPException(status_code=400, detail="Empty audio payload received.")

    result: STTResult = stt_engine.transcribe_audio_bytes(audio_bytes, language=language)
    return TranscribeResponse(
        transcript=result.transcript,
        confidence=result.confidence,
        detected_language=result.detected_language,
        duration_sec=result.duration_sec,
        latency_ms=result.latency_ms,
        speech_detected=result.speech_detected,
    )


@router.post("/synthesize", response_model=TTSAudioResponse)
async def synthesize_speech(request: SynthesizeRequest) -> TTSAudioResponse:
    """
    Synthesize natural voice audio waveform from text.
    """
    if not request.text or not request.text.strip():
        raise HTTPException(status_code=400, detail="Text cannot be empty.")

    audio_res = tts_engine.synthesize(
        text=request.text,
        voice=request.voice,
        speed=request.speed,
    )
    return audio_res


@router.post("", response_model=VoiceRAGResponse)
async def voice_to_voice_rag(
    file: UploadFile = File(...),
    voice: str = Form(default=settings.TTS_DEFAULT_VOICE),
    speed: float = Form(default=settings.TTS_DEFAULT_SPEED),
    language: Optional[str] = Form(default=None),
) -> VoiceRAGResponse:
    """
    End-to-End Voice-to-Voice RAG Pipeline:
    Audio Stream -> VAD/STT -> Guardrails -> Hybrid RAG -> Grounded LLM -> Streaming TTS -> Audio Out.
    """
    timer = StageTimer()

    # 1. Speech-to-Text
    with timer.measure("voice_stt"):
        audio_bytes = await file.read()
        stt_res = stt_engine.transcribe_audio_bytes(audio_bytes, language=language)

    query_text = stt_res.transcript if stt_res.transcript else "Provide a system overview."

    # 2. Grounded RAG Pipeline Execution
    rag_req = AskRequest(query=query_text, top_k=settings.FINAL_TOP_K)
    rag_res = await ask_rag(rag_req)

    # 3. Text-to-Speech Generation
    with timer.measure("voice_tts"):
        tts_res = tts_engine.synthesize(
            text=rag_res.answer,
            voice=voice,
            speed=speed,
        )

    # Merge latency breakdowns
    combined_waterfall = dict(rag_res.latency_waterfall.get("stages_ms", {}))
    combined_waterfall["voice_stt"] = timer.timings.get("voice_stt", 0.0)
    combined_waterfall["voice_tts"] = timer.timings.get("voice_tts", 0.0)

    total_waterfall = {
        "stages_ms": combined_waterfall,
        "total_ms": round(sum(combined_waterfall.values()), 2),
    }

    metrics_collector.record_request(timer, is_voice=True, is_error=False)

    return VoiceRAGResponse(
        query_transcript=query_text,
        answer_text=rag_res.answer,
        thought_process=rag_res.thought_process,
        audio_base64=tts_res.audio_base64,
        audio_format=tts_res.format,
        citations=rag_res.citations,
        grounding_score=rag_res.grounding_score,
        hallucination_risk=rag_res.hallucination_risk,
        retrieved_sources=rag_res.retrieved_sources,
        latency_waterfall=total_waterfall,
        detected_language=stt_res.detected_language,
    )
