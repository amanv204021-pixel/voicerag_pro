"""
Document Ingestion & Management API Routes.
"""

import os
from typing import Any, Dict, List, Optional
from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from pydantic import BaseModel
from app.config import settings
from app.core.logging import logger
from app.core.telemetry import metrics_collector
from app.document_processing.chunkers import AutoChunker
from app.document_processing.parsers import DocumentParserRouter
from app.retrieval.bm25 import bm25_index
from app.retrieval.vector_store import vector_store

router = APIRouter(prefix="/api", tags=["Documents"])

# In-memory document registry for listing & inspection
document_registry: Dict[str, Dict[str, Any]] = {}


class DocumentSummary(BaseModel):
    doc_id: str
    filename: str
    file_type: str
    title: str
    total_pages: int
    total_tokens: int
    chunk_count: int
    strategy: str
    created_at: float


@router.post("/upload")
async def upload_documents(
    files: List[UploadFile] = File(...),
    strategy: str = Form(default="auto"),
) -> Dict[str, Any]:
    """
    Ingest, parse, chunk, embed, and index one or more documents.
    """
    uploaded_summaries: List[Dict[str, Any]] = []

    for file in files:
        filename = file.filename or "uploaded_file"
        file_bytes = await file.read()

        if not file_bytes:
            continue

        # 1. Parse document structure
        parsed_doc = DocumentParserRouter.parse(file_bytes, filename, file.content_type)

        # 2. Chunk document using selected or auto strategy
        chunks = AutoChunker.chunk_document(parsed_doc, strategy=strategy)

        # 3. Add to Dense Vector Store
        vector_store.add_chunks(chunks)

        # 4. Add to BM25 Lexical Index
        bm25_index.add_chunks(chunks)

        # 5. Update Telemetry metrics
        metrics_collector.update_doc_counts(doc_delta=1, chunk_delta=len(chunks))

        # Register metadata
        doc_info = {
            "doc_id": parsed_doc.doc_id,
            "filename": parsed_doc.filename,
            "file_type": parsed_doc.file_type,
            "title": parsed_doc.title,
            "total_pages": parsed_doc.total_pages,
            "total_tokens": parsed_doc.total_tokens,
            "chunk_count": len(chunks),
            "strategy": strategy,
            "created_at": parsed_doc.created_at,
            "chunks_sample": [
                {
                    "chunk_id": c.chunk_id,
                    "page": c.page,
                    "section": c.section_title,
                    "tokens": c.token_count,
                    "preview": c.text[:120] + "...",
                }
                for c in chunks[:4]
            ],
        }
        document_registry[parsed_doc.doc_id] = doc_info
        uploaded_summaries.append(doc_info)

        logger.info(f"Successfully processed & indexed '{filename}' ({len(chunks)} chunks).")

    return {
        "status": "success",
        "processed_count": len(uploaded_summaries),
        "documents": uploaded_summaries,
    }


@router.get("/documents")
async def list_documents() -> Dict[str, Any]:
    """List all indexed documents with metadata and chunk counts."""
    return {
        "total_documents": len(document_registry),
        "total_chunks": len(vector_store.chunks),
        "documents": list(document_registry.values()),
    }


@router.delete("/documents/{doc_id}")
async def delete_document(doc_id: str) -> Dict[str, Any]:
    """Remove a document and its vectors from both BM25 and Vector databases."""
    if doc_id not in document_registry:
        raise HTTPException(status_code=404, detail="Document not found.")

    v_removed = vector_store.remove_document(doc_id)
    b_removed = bm25_index.remove_document(doc_id)
    del document_registry[doc_id]

    metrics_collector.update_doc_counts(doc_delta=-1, chunk_delta=-v_removed)
    return {
        "status": "deleted",
        "doc_id": doc_id,
        "chunks_removed": v_removed,
    }
