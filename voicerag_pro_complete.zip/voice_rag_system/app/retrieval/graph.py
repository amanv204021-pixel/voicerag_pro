"""
Knowledge Graph & Citation Network Generator.
Extracts entities, document sections, and relationship links for interactive graph visualization.
"""

import re
from typing import Any, Dict, List, Set
from app.document_processing.extractor import DocumentChunk
from app.retrieval.vector_store import vector_store


class KnowledgeGraphEngine:
    """
    Constructs graph nodes and weighted edges linking Documents, Sections, and Entities.
    """

    # Common entity patterns
    ENTITY_PATTERNS = [
        r"\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)+\b",  # Proper names / Multi-word entities
        r"\b(?:RAG|LLM|STT|TTS|VAD|BM25|RRF|BERT|GPT-4|GPT-5|Transformer|API|CPU|GPU)\b",  # Technical acronyms
    ]

    @classmethod
    def build_graph(cls) -> Dict[str, Any]:
        """Build node-link data structure for frontend graph visualization."""
        nodes: List[Dict[str, Any]] = []
        links: List[Dict[str, Any]] = []

        seen_nodes: Set[str] = set()
        doc_node_ids: Dict[str, str] = {}

        # 1. Document & Chunk Nodes
        for cid, chunk in vector_store.chunks.items():
            doc_id = chunk.doc_id
            fname = chunk.metadata.get("filename", "Doc")
            doc_nid = f"doc_{doc_id}"

            if doc_nid not in seen_nodes:
                seen_nodes.add(doc_nid)
                doc_node_ids[doc_id] = doc_nid
                nodes.append({
                    "id": doc_nid,
                    "label": fname,
                    "type": "document",
                    "size": 25,
                    "color": "#6366f1",  # Indigo
                })

            chunk_nid = f"chunk_{cid}"
            if chunk_nid not in seen_nodes:
                seen_nodes.add(chunk_nid)
                nodes.append({
                    "id": chunk_nid,
                    "label": f"{chunk.section_title[:18]}... (p.{chunk.page})",
                    "type": "chunk",
                    "size": 14,
                    "color": "#06b6d4",  # Cyan
                    "text_preview": chunk.text[:120] + "...",
                })
                # Link doc -> chunk
                links.append({
                    "source": doc_nid,
                    "target": chunk_nid,
                    "relationship": "contains",
                    "value": 2,
                })

            # Extract key concept entities in chunk
            for pattern in cls.ENTITY_PATTERNS:
                matches = re.findall(pattern, chunk.text)
                for ent in set(matches[:3]):  # limit top entities
                    ent_nid = f"ent_{ent.lower().replace(' ', '_')}"
                    if ent_nid not in seen_nodes:
                        seen_nodes.add(ent_nid)
                        nodes.append({
                            "id": ent_nid,
                            "label": ent,
                            "type": "entity",
                            "size": 18,
                            "color": "#10b981",  # Emerald
                        })
                    links.append({
                        "source": chunk_nid,
                        "target": ent_nid,
                        "relationship": "mentions",
                        "value": 1,
                    })

        return {
            "nodes": nodes,
            "links": links,
            "summary": {
                "total_nodes": len(nodes),
                "total_links": len(links),
                "documents": sum(1 for n in nodes if n["type"] == "document"),
                "chunks": sum(1 for n in nodes if n["type"] == "chunk"),
                "entities": sum(1 for n in nodes if n["type"] == "entity"),
            }
        }


knowledge_graph_engine = KnowledgeGraphEngine()
