"""
Extractive Context Compression Engine.
Prunes irrelevant sentences from retrieved chunks to optimize token efficiency and minimize noise.
"""

from typing import Any, Dict, List, Tuple
from app.config import settings
from app.core.logging import logger
from app.document_processing.chunkers import split_into_sentences
from app.document_processing.extractor import DocumentChunk
from app.document_processing.parsers import estimate_token_count
from app.retrieval.embeddings import embedding_engine


class ContextCompressor:
    """
    Extractive Context Compressor that removes distractor sentences from retrieved chunks.
    """

    @classmethod
    def compress_chunk(
        cls,
        query: str,
        chunk: DocumentChunk,
        min_sentence_score: float = 0.35,
        target_retention: float = settings.COMPRESSION_RATIO,
    ) -> Tuple[str, Dict[str, Any]]:
        """Extract only high-salience sentences from a chunk."""
        sentences = split_into_sentences(chunk.text)
        if len(sentences) <= 2:
            orig_tok = estimate_token_count(chunk.text)
            return chunk.text, {
                "original_tokens": orig_tok,
                "compressed_tokens": orig_tok,
                "reduction_pct": 0.0,
                "retained_sentences": len(sentences),
                "total_sentences": len(sentences),
            }

        q_lower = query.lower()
        q_words = set([w for w in q_lower.split() if len(w) > 2])

        scored_sentences = []
        for s in sentences:
            s_lower = s.lower()
            overlap = sum(1 for w in q_words if w in s_lower)
            score = overlap / max(1, len(q_words))
            # Boost if query contains specific numbers or capital terms present in sentence
            scored_sentences.append((s, score))

        # Sort by score descending to pick top sentences
        indexed_scores = [(idx, s, score) for idx, (s, score) in enumerate(scored_sentences)]
        # Ensure sentences with highest scores are picked up to target retention
        indexed_scores.sort(key=lambda x: x[2], reverse=True)

        target_count = max(1, int(len(sentences) * target_retention))
        chosen_indices = set([item[0] for item in indexed_scores[:target_count] if item[2] >= min_sentence_score or item[0] == 0])

        if not chosen_indices:
            chosen_indices = {indexed_scores[0][0]}

        # Restore original sentence order
        retained = [sentences[i] for i in sorted(chosen_indices)]
        compressed_text = " ".join(retained)

        orig_tok = estimate_token_count(chunk.text)
        comp_tok = estimate_token_count(compressed_text)
        reduction = round(((orig_tok - comp_tok) / orig_tok * 100) if orig_tok > 0 else 0.0, 1)

        return compressed_text, {
            "original_tokens": orig_tok,
            "compressed_tokens": comp_tok,
            "reduction_pct": reduction,
            "retained_sentences": len(retained),
            "total_sentences": len(sentences),
        }

    @classmethod
    def compress_all(
        cls,
        query: str,
        reranked_results: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        """Apply compression to all reranked chunks."""
        compressed_results = []
        for item in reranked_results:
            chunk: DocumentChunk = item["chunk"]
            comp_text, stats = cls.compress_chunk(query, chunk)
            
            # Create a compressed copy representation
            compressed_item = dict(item)
            compressed_item["compressed_text"] = comp_text
            compressed_item["compression_stats"] = stats
            compressed_results.append(compressed_item)

        return compressed_results


context_compressor = ContextCompressor()
