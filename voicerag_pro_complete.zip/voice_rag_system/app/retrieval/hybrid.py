"""
Hybrid Search Engine combining Dense Vector Search and Sparse BM25 with Reciprocal Rank Fusion (RRF).
Includes Multi-Query Expansion and HyDE (Hypothetical Document Embeddings) support.
"""

from collections import defaultdict
from typing import Any, Dict, List, Optional, Set, Tuple
from app.config import settings
from app.core.logging import logger
from app.document_processing.extractor import DocumentChunk
from app.retrieval.bm25 import bm25_index
from app.retrieval.vector_store import vector_store


class QueryExpander:
    """
    Generates multi-query expansions and hypothetical document formulations (HyDE).
    """

    @staticmethod
    def expand_query(query: str) -> List[str]:
        """Generate semantic query variations for expanded retrieval recall."""
        expansions = [query]
        clean_q = query.strip().rstrip("?").lower()

        # Rule-based query reformulations
        if clean_q.startswith("how to"):
            expansions.append(clean_q.replace("how to", "steps to"))
            expansions.append(clean_q.replace("how to", "guide for"))
        elif clean_q.startswith("what is"):
            expansions.append(clean_q.replace("what is", "definition and explanation of"))
            expansions.append(clean_q.replace("what is", "overview of"))
        elif clean_q.startswith("why"):
            expansions.append(clean_q.replace("why", "reasons and rationale for"))
        elif "compare" in clean_q or "difference" in clean_q:
            expansions.append(f"comparison and trade-offs of {clean_q}")
            expansions.append(f"pros and cons of {clean_q}")

        # HyDE pseudo-document generator
        hyde_doc = f"Detailed technical explanation answering: {query}. Key mechanisms, specifications, and factual details."
        expansions.append(hyde_doc)

        return list(dict.fromkeys(expansions))[:4]


class HybridSearchEngine:
    """
    Executes dense vector search and sparse BM25 search in parallel,
    fusing the candidate rankings using Reciprocal Rank Fusion (RRF).
    """

    def __init__(
        self,
        rrf_k: int = settings.HYBRID_RRF_K,
        dense_weight: float = settings.HYBRID_DENSE_WEIGHT,
        sparse_weight: float = settings.HYBRID_SPARSE_WEIGHT,
    ):
        self.rrf_k = rrf_k
        self.dense_weight = dense_weight
        self.sparse_weight = sparse_weight

    def search(
        self,
        query: str,
        top_k: int = settings.RETRIEVAL_TOP_CANDIDATES,
        use_multi_query: bool = True,
        filter_metadata: Optional[Dict[str, Any]] = None,
    ) -> List[Tuple[DocumentChunk, float, Dict[str, Any]]]:
        """
        Execute Hybrid Search with RRF fusion.
        Returns: List of (DocumentChunk, fused_score, score_breakdown)
        """
        queries = QueryExpander.expand_query(query) if use_multi_query else [query]

        # Accumulated scores: chunk_id -> fused_score
        rrf_scores: Dict[str, float] = defaultdict(float)
        chunk_lookup: Dict[str, DocumentChunk] = {}
        score_breakdowns: Dict[str, Dict[str, Any]] = defaultdict(lambda: {
            "dense_rank": None,
            "dense_score": 0.0,
            "sparse_rank": None,
            "sparse_score": 0.0,
            "rrf_score": 0.0,
        })

        for q_var in queries:
            # 1. Dense Vector Search
            dense_results = vector_store.search_by_text(
                q_var,
                top_k=top_k * 2,
                filter_metadata=filter_metadata,
            )

            for rank, (chunk, score) in enumerate(dense_results, start=1):
                cid = chunk.chunk_id
                chunk_lookup[cid] = chunk
                rrf_increment = self.dense_weight * (1.0 / (self.rrf_k + rank))
                rrf_scores[cid] += rrf_increment
                
                bd = score_breakdowns[cid]
                if bd["dense_rank"] is None or rank < bd["dense_rank"]:
                    bd["dense_rank"] = rank
                    bd["dense_score"] = round(score, 4)

            # 2. Sparse BM25 Search
            sparse_results = bm25_index.search(q_var, top_k=top_k * 2)

            for rank, (chunk, score) in enumerate(sparse_results, start=1):
                cid = chunk.chunk_id
                chunk_lookup[cid] = chunk
                rrf_increment = self.sparse_weight * (1.0 / (self.rrf_k + rank))
                rrf_scores[cid] += rrf_increment

                bd = score_breakdowns[cid]
                if bd["sparse_rank"] is None or rank < bd["sparse_rank"]:
                    bd["sparse_rank"] = rank
                    bd["sparse_score"] = round(score, 4)

        if not rrf_scores:
            return []

        # Sort by final RRF score
        sorted_cids = sorted(rrf_scores.items(), key=lambda x: x[1], reverse=True)[:top_k]

        final_results = []
        for cid, f_score in sorted_cids:
            chunk = chunk_lookup[cid]
            bd = score_breakdowns[cid]
            bd["rrf_score"] = round(f_score, 5)
            final_results.append((chunk, f_score, bd))

        logger.info(f"Hybrid search for query='{query[:40]}...' returned {len(final_results)} candidates.")
        return final_results


hybrid_search_engine = HybridSearchEngine()
