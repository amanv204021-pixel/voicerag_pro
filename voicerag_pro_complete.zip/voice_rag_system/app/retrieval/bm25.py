"""
BM25 Lexical Keyword Search Engine.
Implements Okapi BM25 ranking algorithm with tunable k1 and b parameters.
"""

import math
import re
from collections import Counter, defaultdict
from typing import Any, Dict, List, Optional, Tuple
from app.config import settings
from app.core.logging import logger
from app.document_processing.extractor import DocumentChunk


class BM25Index:
    """
    In-memory Okapi BM25 Index with metadata preservation and token normalization.
    """

    STOPWORDS = {
        "a", "about", "above", "after", "again", "against", "all", "am", "an", "and", "any", "are", "aren't",
        "as", "at", "be", "because", "been", "before", "being", "below", "between", "both", "but", "by",
        "can", "could", "did", "do", "does", "doing", "down", "during", "each", "few", "for", "from",
        "further", "had", "has", "have", "having", "he", "her", "here", "hers", "herself", "him", "himself",
        "his", "how", "i", "if", "in", "into", "is", "it", "its", "itself", "just", "me", "more", "most",
        "my", "myself", "no", "nor", "not", "now", "of", "off", "on", "once", "only", "or", "other", "our",
        "ours", "ourselves", "out", "over", "own", "same", "she", "should", "so", "some", "such", "than",
        "that", "the", "their", "theirs", "them", "themselves", "then", "there", "these", "they", "this",
        "those", "through", "to", "too", "under", "until", "up", "very", "was", "we", "were", "what", "when",
        "where", "which", "while", "who", "whom", "why", "with", "would", "you", "your", "yours", "yourself"
    }

    def __init__(self, k1: float = settings.BM25_K1, b: float = settings.BM25_B):
        self.k1 = k1
        self.b = b
        self.corpus_size = 0
        self.avg_doc_len = 0.0
        self.doc_lengths: Dict[str, int] = {}
        self.inverted_index: Dict[str, Dict[str, int]] = defaultdict(dict)  # term -> {chunk_id -> tf}
        self.idf_cache: Dict[str, float] = {}
        self.chunks_map: Dict[str, DocumentChunk] = {}

    def tokenize(self, text: str) -> List[str]:
        """Normalize and tokenize text into cleaned keyword tokens."""
        clean = re.sub(r"[^\w\s]", " ", text.lower())
        tokens = [t for t in clean.split() if len(t) > 1 and t not in self.STOPWORDS]
        return tokens

    def add_chunks(self, chunks: List[DocumentChunk]) -> None:
        """Add a batch of chunks into the BM25 index and recompute statistics."""
        for chunk in chunks:
            self.chunks_map[chunk.chunk_id] = chunk
            tokens = self.tokenize(chunk.text)
            doc_len = len(tokens)
            self.doc_lengths[chunk.chunk_id] = doc_len

            term_counts = Counter(tokens)
            for term, count in term_counts.items():
                self.inverted_index[term][chunk.chunk_id] = count

        self._recompute_stats()
        logger.info(f"BM25 index updated: total_docs={self.corpus_size}, terms={len(self.inverted_index)}")

    def _recompute_stats(self) -> None:
        """Recompute corpus statistics and IDF cache."""
        self.corpus_size = len(self.chunks_map)
        if self.corpus_size == 0:
            self.avg_doc_len = 0.0
            self.idf_cache.clear()
            return

        total_len = sum(self.doc_lengths.values())
        self.avg_doc_len = total_len / self.corpus_size

        # Compute IDF with smoothing: log( (N - n + 0.5)/(n + 0.5) + 1 )
        self.idf_cache = {}
        for term, posting in self.inverted_index.items():
            doc_freq = len(posting)
            idf = math.log(((self.corpus_size - doc_freq + 0.5) / (doc_freq + 0.5)) + 1.0)
            self.idf_cache[term] = max(0.0, idf)

    def search(self, query: str, top_k: int = 10) -> List[Tuple[DocumentChunk, float]]:
        """Search BM25 index and return scored document chunks."""
        if self.corpus_size == 0:
            return []

        tokens = self.tokenize(query)
        if not tokens:
            return []

        scores: Dict[str, float] = defaultdict(float)

        for term in tokens:
            if term not in self.inverted_index:
                continue

            idf = self.idf_cache.get(term, 0.0)
            postings = self.inverted_index[term]

            for chunk_id, tf in postings.items():
                doc_len = self.doc_lengths.get(chunk_id, self.avg_doc_len)
                # BM25 tf normalization formula
                numerator = tf * (self.k1 + 1.0)
                denominator = tf + self.k1 * (1.0 - self.b + self.b * (doc_len / (self.avg_doc_len or 1.0)))
                scores[chunk_id] += idf * (numerator / denominator)

        if not scores:
            return []

        # Sort by score descending
        sorted_results = sorted(scores.items(), key=lambda x: x[1], reverse=True)[:top_k]
        return [(self.chunks_map[cid], score) for cid, score in sorted_results]

    def remove_document(self, doc_id: str) -> int:
        """Remove all chunks associated with a doc_id."""
        to_delete = [cid for cid, chunk in self.chunks_map.items() if chunk.doc_id == doc_id]
        for cid in to_delete:
            del self.chunks_map[cid]
            if cid in self.doc_lengths:
                del self.doc_lengths[cid]
            for term in list(self.inverted_index.keys()):
                if cid in self.inverted_index[term]:
                    del self.inverted_index[term][cid]
                if not self.inverted_index[term]:
                    del self.inverted_index[term]

        self._recompute_stats()
        return len(to_delete)

    def clear(self) -> None:
        """Reset index."""
        self.chunks_map.clear()
        self.doc_lengths.clear()
        self.inverted_index.clear()
        self.idf_cache.clear()
        self.corpus_size = 0
        self.avg_doc_len = 0.0


bm25_index = BM25Index()
