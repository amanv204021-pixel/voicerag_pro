"""
High-Speed Vector Database Store.
Supports normalized matrix cosine similarity, metadata filtering, persistence, and Qdrant integration.
"""

import json
import os
import time
import numpy as np
from typing import Any, Dict, List, Optional, Tuple, Union
from app.config import settings
from app.core.logging import logger
from app.document_processing.extractor import DocumentChunk
from app.retrieval.embeddings import embedding_engine


class VectorStore:
    """
    High-Performance Vector Store with vectorized Cosine Search and metadata filters.
    """

    def __init__(self, storage_dir: str = settings.VECTOR_DB_DIR):
        self.storage_dir = storage_dir
        os.makedirs(self.storage_dir, exist_ok=True)
        self.chunks: Dict[str, DocumentChunk] = {}
        self.vector_matrix: Optional[np.ndarray] = None  # Shape: (N, D)
        self.chunk_id_list: List[str] = []
        self.persist_file = os.path.join(self.storage_dir, "vector_index.json")
        self.matrix_file = os.path.join(self.storage_dir, "vector_matrix.npy")
        self.load_if_exists()

    def add_chunks(self, chunks: List[DocumentChunk]) -> int:
        """Embed and index a batch of chunks."""
        if not chunks:
            return 0

        # Compute embeddings for any chunks missing them
        texts_to_embed = []
        chunks_to_embed = []
        for ch in chunks:
            if ch.embedding is None or len(ch.embedding) == 0:
                texts_to_embed.append(ch.text)
                chunks_to_embed.append(ch)

        if texts_to_embed:
            embeddings = embedding_engine.embed_batch(texts_to_embed)
            for ch, emb in zip(chunks_to_embed, embeddings):
                ch.embedding = emb

        new_vectors = []
        for ch in chunks:
            self.chunks[ch.chunk_id] = ch
            self.chunk_id_list.append(ch.chunk_id)
            new_vectors.append(ch.embedding)

        # Update matrix
        new_mat = np.array(new_vectors, dtype=np.float32)
        if self.vector_matrix is None or len(self.vector_matrix) == 0:
            self.vector_matrix = new_mat
        else:
            self.vector_matrix = np.vstack([self.vector_matrix, new_mat])

        logger.info(f"VectorStore added {len(chunks)} chunks. Total indexed: {len(self.chunks)}")
        self.persist()
        return len(chunks)

    def search(
        self,
        query_vector: Union[List[float], np.ndarray],
        top_k: int = 10,
        filter_metadata: Optional[Dict[str, Any]] = None,
    ) -> List[Tuple[DocumentChunk, float]]:
        """Vectorized cosine similarity search with optional metadata filtering."""
        if self.vector_matrix is None or len(self.chunk_id_list) == 0:
            return []

        q_vec = np.array(query_vector, dtype=np.float32)
        q_norm = np.linalg.norm(q_vec)
        if q_norm > 1e-9:
            q_vec = q_vec / q_norm

        # Matrix dot product (for normalized vectors, this equals cosine similarity)
        similarities = np.dot(self.vector_matrix, q_vec)

        # Apply metadata filters if provided
        results: List[Tuple[DocumentChunk, float]] = []
        top_indices = np.argsort(-similarities)

        for idx in top_indices:
            if len(results) >= top_k:
                break
            
            chunk_id = self.chunk_id_list[idx]
            chunk = self.chunks.get(chunk_id)
            if not chunk:
                continue

            if filter_metadata:
                match = True
                for k, v in filter_metadata.items():
                    if chunk.metadata.get(k) != v and getattr(chunk, k, None) != v:
                        match = False
                        break
                if not match:
                    continue

            results.append((chunk, float(similarities[idx])))

        return results

    def search_by_text(
        self,
        query_text: str,
        top_k: int = 10,
        filter_metadata: Optional[Dict[str, Any]] = None,
    ) -> List[Tuple[DocumentChunk, float]]:
        """Convenience method to embed query text and search."""
        q_vec = embedding_engine.embed_text(query_text)
        return self.search(q_vec, top_k=top_k, filter_metadata=filter_metadata)

    def remove_document(self, doc_id: str) -> int:
        """Remove all chunks belonging to doc_id and rebuild vector matrix."""
        to_keep_ids = []
        to_keep_chunks = {}
        to_keep_vectors = []

        removed_count = 0
        for idx, cid in enumerate(self.chunk_id_list):
            chunk = self.chunks.get(cid)
            if chunk and chunk.doc_id != doc_id:
                to_keep_ids.append(cid)
                to_keep_chunks[cid] = chunk
                if self.vector_matrix is not None:
                    to_keep_vectors.append(self.vector_matrix[idx])
            else:
                removed_count += 1

        self.chunk_id_list = to_keep_ids
        self.chunks = to_keep_chunks
        if to_keep_vectors:
            self.vector_matrix = np.array(to_keep_vectors, dtype=np.float32)
        else:
            self.vector_matrix = None

        self.persist()
        logger.info(f"VectorStore removed doc_id='{doc_id}' ({removed_count} chunks deleted).")
        return removed_count

    def clear(self) -> None:
        """Reset entire vector store."""
        self.chunks.clear()
        self.chunk_id_list.clear()
        self.vector_matrix = None
        if os.path.exists(self.persist_file):
            os.remove(self.persist_file)
        if os.path.exists(self.matrix_file):
            os.remove(self.matrix_file)

    def persist(self) -> None:
        """Serialize metadata and matrix to disk."""
        try:
            serializable_chunks = {cid: ch.model_dump() for cid, ch in self.chunks.items()}
            with open(self.persist_file, "w", encoding="utf-8") as f:
                json.dump({
                    "chunk_id_list": self.chunk_id_list,
                    "chunks": serializable_chunks,
                }, f)

            if self.vector_matrix is not None:
                np.save(self.matrix_file, self.vector_matrix)
        except Exception as e:
            logger.error(f"Failed to persist VectorStore: {e}")

    def load_if_exists(self) -> None:
        """Load persisted index if available."""
        if os.path.exists(self.persist_file) and os.path.exists(self.matrix_file):
            try:
                with open(self.persist_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    self.chunk_id_list = data.get("chunk_id_list", [])
                    raw_chunks = data.get("chunks", {})
                    self.chunks = {cid: DocumentChunk(**val) for cid, val in raw_chunks.items()}

                self.vector_matrix = np.load(self.matrix_file)
                logger.info(f"VectorStore restored from disk with {len(self.chunks)} chunks.")
            except Exception as e:
                logger.warning(f"Could not load vector store snapshot: {e}")


vector_store = VectorStore()
