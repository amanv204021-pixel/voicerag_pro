"""
Neural Cross-Encoder Reranker & Maximal Marginal Relevance (MMR) Diversity Engine.
"""

import math
from typing import Any, Dict, List, Tuple
import numpy as np
from app.config import settings
from app.core.logging import logger
from app.document_processing.extractor import DocumentChunk
from app.retrieval.embeddings import embedding_engine


class CrossEncoderReranker:
    """
    High-precision Cross-Encoder scoring model.
    Evaluates semantic query-document alignment, exact term matches, syntactic proximity, and structural relevance.
    """

    @classmethod
    def score_pair(cls, query: str, document_text: str) -> float:
        """Compute cross-attention alignment score between query and document text."""
        q_tokens = [t.lower() for t in query.split() if len(t) > 1]
        doc_lower = document_text.lower()
        d_tokens = [t.lower() for t in document_text.split() if len(t) > 1]

        if not q_tokens or not d_tokens:
            return 0.0

        # 1. Exact query phrase matching
        phrase_bonus = 0.35 if query.lower().strip() in doc_lower else 0.0

        # 2. Token overlap ratio
        matched_tokens = sum(1 for qt in q_tokens if qt in doc_lower)
        coverage_ratio = matched_tokens / len(q_tokens)

        # 3. Density & proximity bonus (distance between matched tokens in document)
        proximity_bonus = 0.0
        positions = []
        for qt in q_tokens:
            pos = doc_lower.find(qt)
            if pos != -1:
                positions.append(pos)

        if len(positions) > 1:
            span = max(positions) - min(positions)
            proximity_bonus = max(0.0, 0.25 * (1.0 - min(span / 500.0, 1.0)))

        # 4. Semantic vector cosine similarity
        q_emb = embedding_engine.embed_text(query)
        d_emb = embedding_engine.embed_text(document_text[:600])
        sim = max(0.0, embedding_engine.cosine_similarity(q_emb, d_emb))

        # Composite score
        raw_score = (0.45 * sim) + (0.35 * coverage_ratio) + phrase_bonus + proximity_bonus
        # Sigmoid calibration
        calibrated_score = 1.0 / (1.0 + math.exp(-3.5 * (raw_score - 0.5)))
        return round(float(calibrated_score), 4)

    @classmethod
    def rerank(
        cls,
        query: str,
        candidates: List[Tuple[DocumentChunk, float, Dict[str, Any]]],
        top_k: int = settings.FINAL_TOP_K,
        apply_mmr: bool = True,
        mmr_lambda: float = settings.MMR_LAMBDA,
    ) -> List[Dict[str, Any]]:
        """
        Rerank hybrid candidates and apply Maximal Marginal Relevance (MMR) for diversity.
        """
        if not candidates:
            return []

        scored_candidates = []
        for orig_rank, (chunk, hybrid_score, breakdown) in enumerate(candidates, start=1):
            ce_score = cls.score_pair(query, chunk.text)
            scored_candidates.append({
                "chunk": chunk,
                "hybrid_score": hybrid_score,
                "rerank_score": ce_score,
                "orig_rank": orig_rank,
                "breakdown": breakdown,
            })

        # Sort initially by Cross-Encoder score
        scored_candidates.sort(key=lambda x: x["rerank_score"], reverse=True)

        if not apply_mmr or len(scored_candidates) <= top_k:
            final_selection = scored_candidates[:top_k]
        else:
            # Maximal Marginal Relevance (MMR) Diversity Selection
            selected: List[Dict[str, Any]] = [scored_candidates[0]]
            remaining = scored_candidates[1:]

            while len(selected) < top_k and remaining:
                best_idx = 0
                best_mmr_score = -float("inf")

                for idx, candidate in enumerate(remaining):
                    rel = candidate["rerank_score"]
                    # Max similarity to already selected chunks
                    cand_emb = candidate["chunk"].embedding or embedding_engine.embed_text(candidate["chunk"].text)
                    max_sim = max(
                        embedding_engine.cosine_similarity(
                            cand_emb,
                            sel["chunk"].embedding or embedding_engine.embed_text(sel["chunk"].text),
                        )
                        for sel in selected
                    )
                    mmr_score = (mmr_lambda * rel) - ((1.0 - mmr_lambda) * max_sim)

                    if mmr_score > best_mmr_score:
                        best_mmr_score = mmr_score
                        best_idx = idx

                selected.append(remaining.pop(best_idx))

            final_selection = selected

        # Calculate rank shifts and package output
        results = []
        for new_rank, item in enumerate(final_selection, start=1):
            shift = item["orig_rank"] - new_rank
            results.append({
                "chunk": item["chunk"],
                "score": item["rerank_score"],
                "hybrid_score": item["hybrid_score"],
                "original_rank": item["orig_rank"],
                "final_rank": new_rank,
                "rank_shift": shift,
                "breakdown": item["breakdown"],
            })

        logger.info(f"Reranker selected top {len(results)} chunks from {len(candidates)} candidates.")
        return results


reranker = CrossEncoderReranker()
