"""
Citation Verification and Grounding Validation Engine.
Cross-verifies claims, validates citations against source chunks, and computes Grounding Confidence Scores.
"""

import re
from typing import Any, Dict, List, Set, Tuple
from pydantic import BaseModel, Field
from app.document_processing.extractor import DocumentChunk


class VerifiedCitation(BaseModel):
    citation_id: int
    filename: str
    page: int
    section_title: str
    snippet_preview: str
    chunk_id: str
    relevance_score: float


class GroundingEvaluationResult(BaseModel):
    is_grounded: bool
    grounding_score: float  # 0.0 to 1.0
    citations: List[VerifiedCitation] = Field(default_factory=list)
    unverified_claims: List[str] = Field(default_factory=list)
    hallucination_risk: str  # 'LOW', 'MEDIUM', 'HIGH'


class CitationValidator:
    """
    Validates model output against retrieved knowledge chunks to prevent hallucinations.
    """

    CITATION_PATTERN = re.compile(
        r"\[Doc(?:ument)?:\s*([^,\]]+)(?:,\s*Page:\s*(\d+))?(?:,\s*Section:\s*([^\]]+))?\]",
        re.IGNORECASE,
    )
    ALT_CITATION_PATTERN = re.compile(r"\[Document\s*(\d+)\]", re.IGNORECASE)

    @classmethod
    def extract_and_verify(
        cls,
        response_text: str,
        retrieved_items: List[Dict[str, Any]],
    ) -> GroundingEvaluationResult:
        """Extract citations and evaluate factual grounding against retrieved sources."""
        if not response_text:
            return GroundingEvaluationResult(
                is_grounded=False,
                grounding_score=0.0,
                citations=[],
                hallucination_risk="HIGH",
            )

        citations: List[VerifiedCitation] = []
        seen_chunks: Set[str] = set()

        # Match named citations: [Doc: name.pdf, Page: 1, Section: Title]
        matches = cls.CITATION_PATTERN.finditer(response_text)
        cit_idx = 1

        for match in matches:
            fname = match.group(1).strip()
            page = int(match.group(2)) if match.group(2) else 1
            section = match.group(3).strip() if match.group(3) else "General"

            # Find matching retrieved chunk
            matched_chunk = None
            matched_score = 0.0
            for item in retrieved_items:
                chunk: DocumentChunk = item["chunk"]
                if fname.lower() in chunk.metadata.get("filename", "").lower() or fname.lower() in chunk.section_title.lower():
                    matched_chunk = chunk
                    matched_score = item.get("score", 0.0)
                    break

            if matched_chunk and matched_chunk.chunk_id not in seen_chunks:
                seen_chunks.add(matched_chunk.chunk_id)
                citations.append(VerifiedCitation(
                    citation_id=cit_idx,
                    filename=matched_chunk.metadata.get("filename", fname),
                    page=matched_chunk.page,
                    section_title=matched_chunk.section_title,
                    snippet_preview=matched_chunk.text[:140] + "...",
                    chunk_id=matched_chunk.chunk_id,
                    relevance_score=matched_score,
                ))
                cit_idx += 1

        # Also match indexed citations: [Document 1]
        alt_matches = cls.ALT_CITATION_PATTERN.finditer(response_text)
        for m in alt_matches:
            doc_num = int(m.group(1))
            if 1 <= doc_num <= len(retrieved_items):
                item = retrieved_items[doc_num - 1]
                chunk: DocumentChunk = item["chunk"]
                if chunk.chunk_id not in seen_chunks:
                    seen_chunks.add(chunk.chunk_id)
                    citations.append(VerifiedCitation(
                        citation_id=cit_idx,
                        filename=chunk.metadata.get("filename", "Document"),
                        page=chunk.page,
                        section_title=chunk.section_title,
                        snippet_preview=chunk.text[:140] + "...",
                        chunk_id=chunk.chunk_id,
                        relevance_score=item.get("score", 0.0),
                    ))
                    cit_idx += 1

        # If no explicit citation tag was written by LLM, automatically link top retrieved sources
        if not citations and retrieved_items:
            for idx, item in enumerate(retrieved_items[:3], start=1):
                chunk = item["chunk"]
                citations.append(VerifiedCitation(
                    citation_id=idx,
                    filename=chunk.metadata.get("filename", "Document"),
                    page=chunk.page,
                    section_title=chunk.section_title,
                    snippet_preview=chunk.text[:140] + "...",
                    chunk_id=chunk.chunk_id,
                    relevance_score=item.get("score", 0.0),
                ))

        # Strip citation tags from text before computing factual grounding score
        text_without_citations = cls.CITATION_PATTERN.sub("", response_text)
        text_without_citations = cls.ALT_CITATION_PATTERN.sub("", text_without_citations)

        # Compute Grounding Score based on vocabulary & token overlap with retrieved contexts
        all_context_tokens = set()
        for item in retrieved_items:
            chunk = item["chunk"]
            clean_ctx = re.sub(r"[^\w\s]", " ", chunk.text.lower())
            all_context_tokens.update(clean_ctx.split())

        clean_resp = re.sub(r"[^\w\s]", " ", text_without_citations.lower())
        resp_tokens = [w for w in clean_resp.split() if len(w) > 2]

        if resp_tokens:
            grounded_count = sum(1 for w in resp_tokens if w in all_context_tokens)
            grounding_score = round(min(1.0, (grounded_count / len(resp_tokens)) * 1.1), 3)
        else:
            grounding_score = 0.95

        if grounding_score >= 0.70:
            risk = "LOW"
        elif grounding_score >= 0.45:
            risk = "MEDIUM"
        else:
            risk = "HIGH"

        return GroundingEvaluationResult(
            is_grounded=grounding_score >= 0.50,
            grounding_score=grounding_score,
            citations=citations,
            hallucination_risk=risk,
        )


citation_validator = CitationValidator()
