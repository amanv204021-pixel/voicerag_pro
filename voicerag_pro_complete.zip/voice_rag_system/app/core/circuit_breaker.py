"""
Resilience & Fault Tolerance: Circuit Breaker and Retry Engine.
Protects upstream dependencies (Vector Store, LLM, TTS, STT) from cascading failures.
"""

import asyncio
import functools
import random
import time
from enum import Enum
from typing import Any, Callable, Dict, Optional, Type, Tuple
from app.core.logging import logger


class CircuitState(str, Enum):
    CLOSED = "CLOSED"        # Normal operations, passing requests
    OPEN = "OPEN"            # Tripped, immediately failing fast
    HALF_OPEN = "HALF_OPEN"  # Testing if upstream has recovered


class CircuitBreakerOpenException(Exception):
    """Raised when request is rejected by an open circuit."""
    pass


class CircuitBreaker:
    """
    Thread-safe and async-compatible Circuit Breaker.
    """

    def __init__(
        self,
        name: str,
        failure_threshold: int = 5,
        recovery_timeout: float = 30.0,
        expected_exceptions: Tuple[Type[Exception], ...] = (Exception,),
    ):
        self.name = name
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.expected_exceptions = expected_exceptions

        self.state = CircuitState.CLOSED
        self.failure_count = 0
        self.success_count = 0
        self.last_failure_time: Optional[float] = None
        self._lock = asyncio.Lock()

    def _sync_check_state(self) -> None:
        """Evaluate state before execution."""
        now = time.time()
        if self.state == CircuitState.OPEN:
            if self.last_failure_time and (now - self.last_failure_time) >= self.recovery_timeout:
                logger.info(f"CircuitBreaker '{self.name}' transitioning from OPEN to HALF_OPEN (probing).")
                self.state = CircuitState.HALF_OPEN
                self.success_count = 0
            else:
                remaining = round(self.recovery_timeout - (now - (self.last_failure_time or now)), 2)
                raise CircuitBreakerOpenException(
                    f"Circuit '{self.name}' is OPEN. Fast failing request. Retry in {remaining}s."
                )

    def record_success(self) -> None:
        """Handle successful call."""
        if self.state == CircuitState.HALF_OPEN:
            self.success_count += 1
            if self.success_count >= 2:
                logger.info(f"CircuitBreaker '{self.name}' recovered: transitioning to CLOSED.")
                self.state = CircuitState.CLOSED
                self.failure_count = 0
                self.success_count = 0
        elif self.state == CircuitState.CLOSED:
            self.failure_count = 0

    def record_failure(self, exc: Exception) -> None:
        """Handle failure call."""
        self.last_failure_time = time.time()
        self.failure_count += 1
        logger.warning(
            f"CircuitBreaker '{self.name}' recorded failure ({self.failure_count}/{self.failure_threshold}): {exc}"
        )

        if self.state == CircuitState.HALF_OPEN or self.failure_count >= self.failure_threshold:
            logger.error(f"CircuitBreaker '{self.name}' TRIPPED to OPEN state due to consecutive failures.")
            self.state = CircuitState.OPEN

    async def call_async(self, func: Callable, *args: Any, **kwargs: Any) -> Any:
        """Execute async callable wrapped in circuit breaker."""
        async with self._lock:
            self._sync_check_state()

        try:
            result = await func(*args, **kwargs)
            async with self._lock:
                self.record_success()
            return result
        except self.expected_exceptions as exc:
            async with self._lock:
                self.record_failure(exc)
            raise exc

    def call(self, func: Callable, *args: Any, **kwargs: Any) -> Any:
        """Execute sync callable wrapped in circuit breaker."""
        self._sync_check_state()
        try:
            result = func(*args, **kwargs)
            self.record_success()
            return result
        except self.expected_exceptions as exc:
            self.record_failure(exc)
            raise exc

    def get_status(self) -> Dict[str, Any]:
        """Return diagnostic metrics of the circuit breaker."""
        return {
            "name": self.name,
            "state": self.state.value,
            "failure_count": self.failure_count,
            "threshold": self.failure_threshold,
            "last_failure_time": self.last_failure_time,
            "recovery_timeout_sec": self.recovery_timeout,
        }


def retry_with_backoff(
    max_retries: int = 3,
    initial_delay: float = 0.2,
    backoff_factor: float = 2.0,
    jitter: bool = True,
    exceptions: Tuple[Type[Exception], ...] = (Exception,),
):
    """
    Decorator for retrying async or sync functions with exponential backoff and jitter.
    """
    def decorator(func: Callable) -> Callable:
        if asyncio.iscoroutinefunction(func):
            @functools.wraps(func)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                delay = initial_delay
                last_exc = None
                for attempt in range(1, max_retries + 1):
                    try:
                        return await func(*args, **kwargs)
                    except exceptions as e:
                        last_exc = e
                        if attempt == max_retries:
                            logger.error(f"Function {func.__name__} failed after {max_retries} attempts: {e}")
                            raise
                        sleep_time = delay * (random.uniform(0.8, 1.2) if jitter else 1.0)
                        logger.warning(
                            f"Attempt {attempt}/{max_retries} failed for {func.__name__}: {e}. Retrying in {sleep_time:.2f}s..."
                        )
                        await asyncio.sleep(sleep_time)
                        delay *= backoff_factor
                raise last_exc  # type: ignore
            return async_wrapper
        else:
            @functools.wraps(func)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                delay = initial_delay
                last_exc = None
                for attempt in range(1, max_retries + 1):
                    try:
                        return func(*args, **kwargs)
                    except exceptions as e:
                        last_exc = e
                        if attempt == max_retries:
                            logger.error(f"Function {func.__name__} failed after {max_retries} attempts: {e}")
                            raise
                        sleep_time = delay * (random.uniform(0.8, 1.2) if jitter else 1.0)
                        logger.warning(
                            f"Attempt {attempt}/{max_retries} failed for {func.__name__}: {e}. Retrying in {sleep_time:.2f}s..."
                        )
                        time.sleep(sleep_time)
                        delay *= backoff_factor
                raise last_exc  # type: ignore
            return sync_wrapper
    return decorator
