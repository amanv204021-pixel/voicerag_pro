"""
Telemetry, Latency Profiler, and Prometheus Metrics Exporter.
Tracks granular timing for every step in the Voice RAG pipeline.
"""

import time
import numpy as np
from contextlib import contextmanager
from typing import Any, Dict, Generator, List, Optional
from collections import defaultdict
import threading


class StageTimer:
    """
    Timer for profiling individual pipeline stages with microsecond precision.
    """

    def __init__(self) -> None:
        self.timings: Dict[str, float] = {}
        self.start_time: float = time.perf_counter()

    @contextmanager
    def measure(self, stage_name: str) -> Generator[None, None, None]:
        t0 = time.perf_counter()
        try:
            yield
        finally:
            t1 = time.perf_counter()
            elapsed_ms = (t1 - t0) * 1000.0
            self.timings[stage_name] = round(elapsed_ms, 2)

    def total_elapsed_ms(self) -> float:
        return round((time.perf_counter() - self.start_time) * 1000.0, 2)

    def get_summary(self) -> Dict[str, Any]:
        return {
            "stages_ms": self.timings,
            "total_ms": self.total_elapsed_ms(),
        }


class MetricsCollector:
    """
    Thread-safe collector for global latency percentiles, throughput, and error counters.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self.stage_latencies: Dict[str, List[float]] = defaultdict(list)
        self.e2e_latencies: List[float] = []
        self.request_count: int = 0
        self.error_count: int = 0
        self.voice_request_count: int = 0
        self.document_count: int = 0
        self.chunk_count: int = 0

    def record_request(self, timer: StageTimer, is_voice: bool = False, is_error: bool = False) -> None:
        with self._lock:
            self.request_count += 1
            if is_voice:
                self.voice_request_count += 1
            if is_error:
                self.error_count += 1
                return

            total_ms = timer.total_elapsed_ms()
            self.e2e_latencies.append(total_ms)
            for stage, ms in timer.timings.items():
                self.stage_latencies[stage].append(ms)

            # Keep window size manageable (last 5,000 samples)
            if len(self.e2e_latencies) > 5000:
                self.e2e_latencies = self.e2e_latencies[-5000:]
                for st in self.stage_latencies:
                    self.stage_latencies[st] = self.stage_latencies[st][-5000:]

    def update_doc_counts(self, doc_delta: int, chunk_delta: int) -> None:
        with self._lock:
            self.document_count += doc_delta
            self.chunk_count += chunk_delta

    @staticmethod
    def _compute_percentiles(values: List[float]) -> Dict[str, float]:
        if not values:
            return {"p50": 0.0, "p70": 0.0, "p90": 0.0, "p95": 0.0, "p99": 0.0, "avg": 0.0, "min": 0.0, "max": 0.0}
        arr = np.array(values)
        return {
            "p50": round(float(np.percentile(arr, 50)), 2),
            "p70": round(float(np.percentile(arr, 70)), 2),
            "p90": round(float(np.percentile(arr, 90)), 2),
            "p95": round(float(np.percentile(arr, 95)), 2),
            "p99": round(float(np.percentile(arr, 99)), 2),
            "avg": round(float(np.mean(arr)), 2),
            "min": round(float(np.min(arr)), 2),
            "max": round(float(np.max(arr)), 2),
        }

    def get_latency_report(self) -> Dict[str, Any]:
        with self._lock:
            report: Dict[str, Any] = {
                "e2e_latency_ms": self._compute_percentiles(self.e2e_latencies),
                "stages": {},
                "counters": {
                    "total_requests": self.request_count,
                    "voice_requests": self.voice_request_count,
                    "error_requests": self.error_count,
                    "success_rate_pct": round(
                        ((self.request_count - self.error_count) / self.request_count * 100)
                        if self.request_count > 0
                        else 100.0,
                        2,
                    ),
                    "indexed_documents": self.document_count,
                    "indexed_chunks": self.chunk_count,
                },
            }
            for stage, vals in self.stage_latencies.items():
                report["stages"][stage] = self._compute_percentiles(vals)
            return report

    def get_prometheus_metrics(self) -> str:
        """Generate Prometheus exposition format string."""
        with self._lock:
            lines = [
                "# HELP voice_rag_requests_total Total number of RAG requests",
                "# TYPE voice_rag_requests_total counter",
                f"voice_rag_requests_total {self.request_count}",
                "# HELP voice_rag_errors_total Total number of failed RAG requests",
                "# TYPE voice_rag_errors_total counter",
                f"voice_rag_errors_total {self.error_count}",
                "# HELP voice_rag_documents_total Total indexed documents",
                "# TYPE voice_rag_documents_total gauge",
                f"voice_rag_documents_total {self.document_count}",
                "# HELP voice_rag_chunks_total Total indexed knowledge chunks",
                "# TYPE voice_rag_chunks_total gauge",
                f"voice_rag_chunks_total {self.chunk_count}",
            ]
            e2e = self._compute_percentiles(self.e2e_latencies)
            lines.extend([
                "# HELP voice_rag_e2e_latency_p50_ms End to End latency P50",
                "# TYPE voice_rag_e2e_latency_p50_ms gauge",
                f"voice_rag_e2e_latency_p50_ms {e2e['p50']}",
                "# HELP voice_rag_e2e_latency_p95_ms End to End latency P95",
                "# TYPE voice_rag_e2e_latency_p95_ms gauge",
                f"voice_rag_e2e_latency_p95_ms {e2e['p95']}",
                "# HELP voice_rag_e2e_latency_p99_ms End to End latency P99",
                "# TYPE voice_rag_e2e_latency_p99_ms gauge",
                f"voice_rag_e2e_latency_p99_ms {e2e['p99']}",
            ])
            return "\n".join(lines) + "\n"


# Global telemetry metrics instance
metrics_collector = MetricsCollector()
