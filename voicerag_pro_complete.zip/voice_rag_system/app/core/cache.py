"""
High-Performance In-Memory and Distributed Caching Layer.
Supports TTL expiration, LRU eviction, and hit/miss telemetry.
"""

import hashlib
import json
import time
from collections import OrderedDict
from typing import Any, Dict, Optional, Tuple
from app.core.logging import logger


class LRUCache:
    """
    Thread-safe in-memory LRU Cache with TTL expiration and metrics.
    """

    def __init__(self, max_size: int = 5000, default_ttl_sec: int = 3600):
        self.max_size = max_size
        self.default_ttl_sec = default_ttl_sec
        self._cache: OrderedDict[str, Tuple[Any, float]] = OrderedDict()
        self._hits = 0
        self._misses = 0

    @staticmethod
    def generate_key(prefix: str, payload: Any) -> str:
        """Generate a deterministic SHA-256 cache key."""
        serialized = json.dumps(payload, sort_keys=True, default=str)
        hash_digest = hashlib.sha256(serialized.encode("utf-8")).hexdigest()
        return f"{prefix}:{hash_digest}"

    def get(self, key: str) -> Optional[Any]:
        """Retrieve an item from cache if not expired."""
        if key not in self._cache:
            self._misses += 1
            return None

        val, expire_at = self._cache[key]
        if time.time() > expire_at:
            # Expired
            del self._cache[key]
            self._misses += 1
            return None

        # Move to end to indicate recent use
        self._cache.move_to_end(key)
        self._hits += 1
        return val

    def set(self, key: str, value: Any, ttl_sec: Optional[int] = None) -> None:
        """Store an item in the cache with TTL."""
        ttl = ttl_sec if ttl_sec is not None else self.default_ttl_sec
        expire_at = time.time() + ttl

        if key in self._cache:
            self._cache.move_to_end(key)
        self._cache[key] = (value, expire_at)

        # Evict oldest if exceeding capacity
        if len(self._cache) > self.max_size:
            evicted_key, _ = self._cache.popitem(last=False)
            logger.debug(f"LRUCache evicted key: {evicted_key}")

    def invalidate(self, key: str) -> bool:
        """Explicitly remove a key."""
        if key in self._cache:
            del self._cache[key]
            return True
        return False

    def clear(self) -> None:
        """Clear all entries."""
        self._cache.clear()

    def get_stats(self) -> Dict[str, Any]:
        """Return cache health and hit/miss statistics."""
        total = self._hits + self._misses
        hit_rate = (self._hits / total * 100) if total > 0 else 0.0
        return {
            "size": len(self._cache),
            "max_size": self.max_size,
            "hits": self._hits,
            "misses": self._misses,
            "total_lookups": total,
            "hit_rate_pct": round(hit_rate, 2),
        }


# Global application cache instance
cache = LRUCache(max_size=10000, default_ttl_sec=3600)
