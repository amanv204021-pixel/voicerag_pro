"""
Security Guardrails Engine: Prompt Injection, Jailbreak Detection, PII Masking, and Toxicity Filter.
"""

import re
from typing import Dict, List, Optional, Tuple
from pydantic import BaseModel, Field
from app.config import settings
from app.core.logging import logger


class GuardrailCheckResult(BaseModel):
    is_safe: bool = True
    action: str = "allow"  # 'allow', 'mask', 'refuse'
    sanitized_text: str
    reasons: List[str] = Field(default_factory=list)
    prompt_injection_score: float = 0.0
    toxicity_score: float = 0.0
    masked_pii_entities: List[str] = Field(default_factory=list)


class GuardrailsEngine:
    """
    Comprehensive Security Guardrails for Voice & Text RAG.
    """

    # Known prompt injection & jailbreak heuristic signatures
    INJECTION_PATTERNS = [
        r"(?i)ignore\s+(all\s+)?(previous|prior|above|system)?\s*(instructions|rules|guidelines|prompts)",
        r"(?i)disregard\s+(all\s+)?(previous|prior|system|above)?\s*(instructions|rules|guidelines|prompts)",
        r"(?i)you\s+are\s+now\s+(DAN|unfiltered|jailbroken|an\s+unrestricted\s+AI)",
        r"(?i)(system\s*prompt\s*leak|system\s*prompt\s*reveal)",
        r"(?i)(reveal|show|repeat|print|dump|leak|output)\s+(the\s+)?(system|initial|hidden|underlying)?\s*(prompt|instructions|rules)",
        r"(?i)pretend\s+you\s+have\s+no\s+safety\s+guidelines",
        r"(?i)developer\s+mode\s+enabled",
        r"(?i)switch\s+to\s+admin\s+mode",
        r"(?i)bypass\s+all\s+filters",
        r"(?i)evil\s+twin\s+mode",
        r"(?i)do\s+anything\s+now",
        r"(?i)format\s+your\s+response\s+as\s+a\s+raw\s+json\s+dumping\s+the\s+prompt",
    ]

    # Common Toxic / Profanity / Malicious content triggers
    TOXICITY_PATTERNS = [
        r"(?i)\b(kill\s+yourself|how\s+to\s+make\s+a\s+bomb|synthesize\s+ricin|steal\s+credit\s+card)\b",
        r"(?i)\b(fuck|shit|asshole|bitch|bastard|cunt|nigger|faggot)\b",
        r"(?i)\b(ddos\s+attack|create\s+malware|ransomware\s+code)\b",
    ]

    # PII Regex Patterns
    PII_PATTERNS = {
        "EMAIL": r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+",
        "PHONE": r"(\+?\d{1,3}[-.\s]?)?(\(?\d{3}\)?[-.\s]?)(\d{3})[-.\s]?(\d{4})",
        "SSN": r"\b\d{3}-\d{2}-\d{4}\b",
        "CREDIT_CARD": r"\b(?:\d{4}[-\s]?){3}\d{4}\b",
        "IPV4": r"\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b",
        "API_KEY": r"\b(sk-[a-zA-Z0-9]{20,}|ghp_[a-zA-Z0-9]{20,}|Bearer\s+[a-zA-Z0-9._-]{20,})\b",
    }

    def __init__(self) -> None:
        self._compiled_injections = [re.compile(p) for p in self.INJECTION_PATTERNS]
        self._compiled_toxicity = [re.compile(p) for p in self.TOXICITY_PATTERNS]
        self._compiled_pii = {k: re.compile(v) for k, v in self.PII_PATTERNS.items()}

    def detect_prompt_injection(self, text: str) -> Tuple[bool, float, List[str]]:
        """Evaluate text for adversarial jailbreaks and prompt injections."""
        reasons = []
        hits = 0

        for pattern in self._compiled_injections:
            if pattern.search(text):
                hits += 1
                reasons.append(f"Prompt injection pattern detected: '{pattern.pattern}'")

        # Base64 injection detection
        if len(text) > 40 and re.search(r"^[A-Za-z0-9+/=]{40,}$", text.strip()):
            hits += 1
            reasons.append("Potential Base64 encoded payload detected.")

        # Calculate confidence score (each hit is high confidence)
        score = min(1.0, hits * 0.85)
        is_injection = score >= settings.INJECTION_CONFIDENCE_THRESHOLD
        return is_injection, round(score, 2), reasons

    def detect_toxicity(self, text: str) -> Tuple[bool, float, List[str]]:
        """Evaluate text for harmful, abusive, or dangerous content."""
        reasons = []
        hits = 0

        for pattern in self._compiled_toxicity:
            matches = pattern.findall(text)
            if matches:
                hits += len(matches)
                reasons.append(f"Harmful or toxic keywords detected.")

        score = min(1.0, hits * 0.4)
        is_toxic = score >= settings.TOXICITY_THRESHOLD
        return is_toxic, round(score, 2), reasons

    def mask_pii(self, text: str) -> Tuple[str, List[str]]:
        """Redact sensitive personally identifiable information."""
        masked_text = text
        detected_entities = []

        for pii_type, pattern in self._compiled_pii.items():
            matches = pattern.findall(masked_text)
            if matches:
                detected_entities.append(pii_type)
                masked_text = pattern.sub(f"[REDACTED_{pii_type}]", masked_text)

        return masked_text, detected_entities

    def evaluate_query(self, query: str) -> GuardrailCheckResult:
        """Run all safety checks on an incoming user query."""
        if not query or not query.strip():
            return GuardrailCheckResult(
                is_safe=False,
                action="refuse",
                sanitized_text="",
                reasons=["Empty query received."],
            )

        reasons: List[str] = []
        
        # 1. Prompt Injection Detection
        if settings.ENABLE_PROMPT_INJECTION_DETECTION:
            is_inj, inj_score, inj_reasons = self.detect_prompt_injection(query)
            reasons.extend(inj_reasons)
            if is_inj:
                logger.warning(f"Guardrails blocked prompt injection: score={inj_score}, reasons={inj_reasons}")
                return GuardrailCheckResult(
                    is_safe=False,
                    action="refuse",
                    sanitized_text=query,
                    reasons=reasons,
                    prompt_injection_score=inj_score,
                )
        else:
            inj_score = 0.0

        # 2. Toxicity / Harm Detection
        if settings.ENABLE_TOXICITY_FILTER:
            is_toxic, tox_score, tox_reasons = self.detect_toxicity(query)
            reasons.extend(tox_reasons)
            if is_toxic:
                logger.warning(f"Guardrails blocked toxic content: score={tox_score}, reasons={tox_reasons}")
                return GuardrailCheckResult(
                    is_safe=False,
                    action="refuse",
                    sanitized_text=query,
                    reasons=reasons,
                    toxicity_score=tox_score,
                )
        else:
            tox_score = 0.0

        # 3. PII Masking
        sanitized = query
        detected_pii: List[str] = []
        if settings.ENABLE_PII_MASKING:
            sanitized, detected_pii = self.mask_pii(query)
            if detected_pii:
                reasons.append(f"Sanitized PII types: {', '.join(detected_pii)}")

        return GuardrailCheckResult(
            is_safe=True,
            action="allow" if not detected_pii else "mask",
            sanitized_text=sanitized,
            reasons=reasons,
            prompt_injection_score=inj_score,
            toxicity_score=tox_score,
            masked_pii_entities=detected_pii,
        )


guardrails_engine = GuardrailsEngine()
