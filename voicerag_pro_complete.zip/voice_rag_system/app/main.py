"""
FastAPI Application Entrypoint.
Assembles routers, middleware, static files, and sample knowledge base initialization.
"""

import os
import time
import uuid
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

from app.config import settings
from app.core.logging import logger, set_correlation_id
from app.core.telemetry import metrics_collector
from app.document_processing.chunkers import AutoChunker
from app.document_processing.parsers import DocumentParserRouter
from app.retrieval.bm25 import bm25_index
from app.retrieval.vector_store import vector_store

# Import API Routers
from app.api.routes_documents import router as doc_router, document_registry
from app.api.routes_rag import router as rag_router
from app.api.routes_voice import router as voice_router
from app.api.routes_benchmark import router as bench_router
from app.api.routes_guardrails import router as guard_router
from app.api.routes_graph import router as graph_router
from app.api.routes_health import router as health_router


def seed_sample_knowledge_base():
    """Populate default sample documents if knowledge base is empty."""
    sample_dir = os.path.join(settings.BASE_DIR, "sample_data")
    if not os.path.exists(sample_dir):
        return

    sample_files = [
        ("ai_agent_architecture.md", "Autonomous AI Agents & RAG Architecture Specification 2026"),
        ("quarterly_earnings_report.txt", "Apex Financial Q3 2026 Global Performance & Revenue"),
        ("quantum_computing_whitepaper.txt", "Topological Quantum Computing & Error Correction"),
        ("sample_medical_guidelines.md", "Clinical Guidelines for Hypertension and Cardiovascular Care"),
        ("multimodal_rag_spec.csv", "Multimodal RAG Specs and Benchmarks Dataset"),
    ]

    for fname, title in sample_files:
        fpath = os.path.join(sample_dir, fname)
        if os.path.exists(fpath):
            try:
                with open(fpath, "rb") as f:
                    file_bytes = f.read()

                parsed = DocumentParserRouter.parse(file_bytes, fname)
                parsed.title = title
                chunks = AutoChunker.chunk_document(parsed, strategy="auto")

                vector_store.add_chunks(chunks)
                bm25_index.add_chunks(chunks)
                metrics_collector.update_doc_counts(doc_delta=1, chunk_delta=len(chunks))

                document_registry[parsed.doc_id] = {
                    "doc_id": parsed.doc_id,
                    "filename": parsed.filename,
                    "file_type": parsed.file_type,
                    "title": parsed.title,
                    "total_pages": parsed.total_pages,
                    "total_tokens": parsed.total_tokens,
                    "chunk_count": len(chunks),
                    "strategy": "auto",
                    "created_at": parsed.created_at,
                    "chunks_sample": [
                        {
                            "chunk_id": c.chunk_id,
                            "page": c.page,
                            "section": c.section_title,
                            "tokens": c.token_count,
                            "preview": c.text[:120] + "...",
                        }
                        for c in chunks[:4]
                    ],
                }
                logger.info(f"Seeded sample knowledge document '{fname}' ({len(chunks)} chunks).")
            except Exception as e:
                logger.error(f"Error seeding sample document '{fname}': {e}")


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info(f"Starting {settings.APP_NAME} v{settings.APP_VERSION} on {settings.HOST}:{settings.PORT}")
    seed_sample_knowledge_base()
    yield
    logger.info(f"Shutting down {settings.APP_NAME}")


app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description="Production-Ready Voice-Enabled Retrieval-Augmented Generation (RAG) System",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

# CORS Configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def correlation_and_timing_middleware(request: Request, call_next):
    cid = request.headers.get("X-Correlation-ID", str(uuid.uuid4()))
    set_correlation_id(cid)
    t0 = time.perf_counter()

    response = await call_next(request)

    elapsed_ms = round((time.perf_counter() - t0) * 1000.0, 2)
    response.headers["X-Correlation-ID"] = cid
    response.headers["X-Response-Time-MS"] = str(elapsed_ms)
    return response


# Register Routers
app.include_router(health_router)
app.include_router(doc_router)
app.include_router(rag_router)
app.include_router(voice_router)
app.include_router(bench_router)
app.include_router(guard_router)
app.include_router(graph_router)

# Mount Static UI Files
static_path = os.path.join(settings.BASE_DIR, "static")
if os.path.exists(static_path):
    app.mount("/static", StaticFiles(directory=static_path), name="static")


@app.get("/")
async def serve_root():
    index_file = os.path.join(settings.BASE_DIR, "static", "index.html")
    if os.path.exists(index_file):
        return FileResponse(index_file)
    return {"message": f"Welcome to {settings.APP_NAME} API. Visit /docs for Swagger UI."}
