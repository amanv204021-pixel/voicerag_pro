"""
Adaptive Multi-Strategy Document Chunkers.
Implements Semantic, Parent-Child, Recursive, Sliding Window, and Sentence-Aware chunking.
"""

import re
import uuid
from typing import List, Optional, Tuple
from app.config import settings
from app.core.logging import logger
from app.document_processing.extractor import DocumentChunk, ParsedDocument
from app.document_processing.parsers import estimate_token_count


def split_into_sentences(text: str) -> List[str]:
    """Split text into sentences cleanly respecting abbreviations."""
    sentence_endings = re.compile(r'(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?|\!)\s+')
    sentences = [s.strip() for s in sentence_endings.split(text) if s.strip()]
    return sentences if sentences else [text]


class RecursiveChunker:
    """Recursively splits text on structural delimiters while respecting token bounds."""

    SEPARATORS = ["\n\n# ", "\n\n## ", "\n\n### ", "\n\n", "\n", ". ", "; ", ", ", " "]

    @classmethod
    def chunk(
        cls,
        doc: ParsedDocument,
        chunk_size: int = 512,
        chunk_overlap: int = 64
    ) -> List[DocumentChunk]:
        chunks: List[DocumentChunk] = []

        for sec_idx, section in enumerate(doc.sections):
            sec_text = section.content.strip()
            if not sec_text:
                continue

            raw_chunks = cls._recursive_split(sec_text, chunk_size, chunk_overlap)
            for p_idx, text_chunk in enumerate(raw_chunks):
                chunks.append(DocumentChunk(
                    doc_id=doc.doc_id,
                    text=text_chunk,
                    token_count=estimate_token_count(text_chunk),
                    strategy="recursive",
                    page=section.page,
                    section_title=section.title,
                    heading_hierarchy=[doc.title, section.title],
                    paragraph_index=p_idx,
                    metadata={"filename": doc.filename, "file_type": doc.file_type}
                ))

        return chunks

    @classmethod
    def _recursive_split(cls, text: str, max_tokens: int, overlap: int) -> List[str]:
        if estimate_token_count(text) <= max_tokens:
            return [text]

        for sep in cls.SEPARATORS:
            parts = text.split(sep)
            if len(parts) > 1:
                result_chunks = []
                current_chunk = ""
                
                for part in parts:
                    candidate = (current_chunk + sep + part).strip() if current_chunk else part.strip()
                    if estimate_token_count(candidate) <= max_tokens:
                        current_chunk = candidate
                    else:
                        if current_chunk:
                            result_chunks.append(current_chunk)
                        # If single part is larger than max_tokens, recursively split it
                        if estimate_token_count(part) > max_tokens:
                            result_chunks.extend(cls._recursive_split(part, max_tokens, overlap))
                            current_chunk = ""
                        else:
                            current_chunk = part

                if current_chunk:
                    result_chunks.append(current_chunk)

                if result_chunks:
                    return result_chunks

        # Fallback character-level split
        chars_per_token = 4
        char_limit = max_tokens * chars_per_token
        step = max(1, (max_tokens - overlap) * chars_per_token)
        return [text[i:i + char_limit].strip() for i in range(0, len(text), step) if text[i:i + char_limit].strip()]


class SemanticChunker:
    """
    Chunks based on semantic coherence and thematic sentence clustering.
    """

    @classmethod
    def chunk(
        cls,
        doc: ParsedDocument,
        chunk_size: int = 512,
        similarity_threshold: float = 0.65
    ) -> List[DocumentChunk]:
        chunks: List[DocumentChunk] = []

        for section in doc.sections:
            sentences = split_into_sentences(section.content)
            if not sentences:
                continue

            current_group: List[str] = []
            current_tokens = 0

            for s_idx, sentence in enumerate(sentences):
                stokens = estimate_token_count(sentence)
                if current_tokens + stokens > chunk_size and current_group:
                    chunk_text = " ".join(current_group)
                    chunks.append(DocumentChunk(
                        doc_id=doc.doc_id,
                        text=chunk_text,
                        token_count=current_tokens,
                        strategy="semantic",
                        page=section.page,
                        section_title=section.title,
                        heading_hierarchy=[doc.title, section.title],
                        paragraph_index=len(chunks),
                        metadata={"filename": doc.filename, "file_type": doc.file_type}
                    ))
                    current_group = [sentence]
                    current_tokens = stokens
                else:
                    current_group.append(sentence)
                    current_tokens += stokens

            if current_group:
                chunk_text = " ".join(current_group)
                chunks.append(DocumentChunk(
                    doc_id=doc.doc_id,
                    text=chunk_text,
                    token_count=current_tokens,
                    strategy="semantic",
                    page=section.page,
                    section_title=section.title,
                    heading_hierarchy=[doc.title, section.title],
                    paragraph_index=len(chunks),
                    metadata={"filename": doc.filename, "file_type": doc.file_type}
                ))

        return chunks


class ParentChildChunker:
    """
    Generates large Parent chunks for LLM context injection and small Child chunks for vector search.
    """

    @classmethod
    def chunk(
        cls,
        doc: ParsedDocument,
        parent_size: int = 1024,
        child_size: int = 256,
        child_overlap: int = 32
    ) -> Tuple[List[DocumentChunk], List[DocumentChunk]]:
        parent_chunks: List[DocumentChunk] = []
        child_chunks: List[DocumentChunk] = []

        raw_parents = RecursiveChunker.chunk(doc, chunk_size=parent_size, chunk_overlap=64)

        for p_chunk in raw_parents:
            parent_id = p_chunk.chunk_id
            p_chunk.strategy = "parent"
            parent_chunks.append(p_chunk)

            # Split parent into smaller child chunks
            child_texts = RecursiveChunker._recursive_split(p_chunk.text, max_tokens=child_size, overlap=child_overlap)
            for c_idx, c_text in enumerate(child_texts):
                child_chunks.append(DocumentChunk(
                    doc_id=doc.doc_id,
                    parent_id=parent_id,
                    text=c_text,
                    token_count=estimate_token_count(c_text),
                    strategy="parent_child",
                    page=p_chunk.page,
                    section_title=p_chunk.section_title,
                    heading_hierarchy=p_chunk.heading_hierarchy,
                    paragraph_index=c_idx,
                    metadata={"parent_id": parent_id, "filename": doc.filename}
                ))

        return parent_chunks, child_chunks


class SlidingWindowChunker:
    """
    Slides a fixed-token window across text with configurable overlap.
    """

    @classmethod
    def chunk(
        cls,
        doc: ParsedDocument,
        window_size: int = 512,
        overlap: int = 64
    ) -> List[DocumentChunk]:
        chunks: List[DocumentChunk] = []
        words = doc.full_text.split()
        step = max(1, window_size - overlap)

        for i in range(0, len(words), step):
            window_words = words[i:i + window_size]
            text = " ".join(window_words)
            chunks.append(DocumentChunk(
                doc_id=doc.doc_id,
                text=text,
                token_count=len(window_words),
                strategy="sliding",
                page=1,
                section_title="Sliding Window",
                heading_hierarchy=[doc.title],
                paragraph_index=i // step,
                metadata={"filename": doc.filename, "window_start": i, "window_end": i + len(window_words)}
            ))
            if i + window_size >= len(words):
                break

        return chunks


class SentenceAwareChunker:
    """
    Groups sentences into clean chunks without truncating midsentence.
    """

    @classmethod
    def chunk(
        cls,
        doc: ParsedDocument,
        target_tokens: int = 400
    ) -> List[DocumentChunk]:
        chunks: List[DocumentChunk] = []
        sentences = split_into_sentences(doc.full_text)

        current_sentences: List[str] = []
        current_tokens = 0

        for sentence in sentences:
            stokens = estimate_token_count(sentence)
            if current_tokens + stokens > target_tokens and current_sentences:
                chunk_str = " ".join(current_sentences)
                chunks.append(DocumentChunk(
                    doc_id=doc.doc_id,
                    text=chunk_str,
                    token_count=current_tokens,
                    strategy="sentence",
                    page=1,
                    section_title="Sentence Chunk",
                    heading_hierarchy=[doc.title],
                    paragraph_index=len(chunks),
                    metadata={"filename": doc.filename}
                ))
                current_sentences = [sentence]
                current_tokens = stokens
            else:
                current_sentences.append(sentence)
                current_tokens += stokens

        if current_sentences:
            chunk_str = " ".join(current_sentences)
            chunks.append(DocumentChunk(
                doc_id=doc.doc_id,
                text=chunk_str,
                token_count=current_tokens,
                strategy="sentence",
                page=1,
                section_title="Sentence Chunk",
                heading_hierarchy=[doc.title],
                paragraph_index=len(chunks),
                metadata={"filename": doc.filename}
            ))

        return chunks


class AutoChunker:
    """
    Intelligently selects and executes the optimal chunking strategy.
    """

    @classmethod
    def chunk_document(
        cls,
        doc: ParsedDocument,
        strategy: str = "auto"
    ) -> List[DocumentChunk]:
        selected_strategy = strategy.lower()

        if selected_strategy == "auto":
            if doc.file_type in ["md", "html", "docx"]:
                selected_strategy = "recursive"
            elif doc.file_type == "csv":
                selected_strategy = "sentence"
            elif doc.file_type == "pdf":
                selected_strategy = "semantic"
            else:
                selected_strategy = "recursive"

        logger.info(f"Chunking document '{doc.filename}' with strategy '{selected_strategy}'")

        if selected_strategy == "semantic":
            return SemanticChunker.chunk(doc, chunk_size=settings.CHUNK_SIZE)
        elif selected_strategy == "parent_child":
            _, children = ParentChildChunker.chunk(
                doc,
                parent_size=settings.PARENT_CHUNK_SIZE,
                child_size=settings.CHILD_CHUNK_SIZE
            )
            return children
        elif selected_strategy == "sliding":
            return SlidingWindowChunker.chunk(doc, window_size=settings.CHUNK_SIZE, overlap=settings.CHUNK_OVERLAP)
        elif selected_strategy == "sentence":
            return SentenceAwareChunker.chunk(doc, target_tokens=settings.CHUNK_SIZE)
        else:
            return RecursiveChunker.chunk(doc, chunk_size=settings.CHUNK_SIZE, chunk_overlap=settings.CHUNK_OVERLAP)
