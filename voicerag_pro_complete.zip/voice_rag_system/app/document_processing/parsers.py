"""
Multi-Format Intelligent Document Parsers.
Extracts title, hierarchy, sections, tables, and page metadata across PDF, DOCX, MD, CSV, HTML, and TXT.
"""

import csv
import io
import os
import re
from typing import BinaryIO, Dict, List, Optional, Tuple, Union
from bs4 import BeautifulSoup
from pypdf import PdfReader
from docx import Document as DocxDocument
from app.core.logging import logger
from app.document_processing.extractor import DocumentSection, DocumentTable, ParsedDocument


def estimate_token_count(text: str) -> int:
    """Rough estimate of token count (standard 1 token ~ 4 chars / 0.75 words)."""
    if not text:
        return 0
    words = len(text.split())
    chars = len(text)
    return max(words, chars // 4)


class PDFParser:
    """Extracts structured text, page numbers, and structural headings from PDF."""

    @staticmethod
    def parse(file_bytes: bytes, filename: str) -> ParsedDocument:
        stream = io.BytesIO(file_bytes)
        reader = PdfReader(stream)
        num_pages = len(reader.pages)
        title = filename
        
        if reader.metadata and reader.metadata.title:
            title = reader.metadata.title

        sections: List[DocumentSection] = []
        full_text_list: List[str] = []

        for page_idx, page in enumerate(reader.pages, start=1):
            text = page.extract_text() or ""
            text = text.strip()
            if not text:
                continue

            full_text_list.append(text)
            
            # Simple heuristic to identify headings in page text
            lines = text.split("\n")
            current_section_title = f"Page {page_idx}"
            current_content: List[str] = []

            for line in lines:
                clean_line = line.strip()
                # If line is short, uppercase or title-like, treat as heading
                if 3 < len(clean_line) < 80 and (clean_line.isupper() or (clean_line.istitle() and not clean_line.endswith("."))):
                    if current_content:
                        sections.append(DocumentSection(
                            title=current_section_title,
                            level=2,
                            content="\n".join(current_content),
                            page=page_idx
                        ))
                        current_content = []
                    current_section_title = clean_line
                else:
                    current_content.append(line)

            if current_content:
                sections.append(DocumentSection(
                    title=current_section_title,
                    level=2,
                    content="\n".join(current_content),
                    page=page_idx
                ))

        combined_text = "\n\n".join(full_text_list)
        return ParsedDocument(
            filename=filename,
            file_type="pdf",
            title=title,
            sections=sections,
            full_text=combined_text,
            total_pages=num_pages,
            total_tokens=estimate_token_count(combined_text),
            metadata={"num_pages": num_pages, "has_metadata": bool(reader.metadata)}
        )


class DocxParser:
    """Extracts structured text, headings (H1-H6), and tables from DOCX."""

    @staticmethod
    def parse(file_bytes: bytes, filename: str) -> ParsedDocument:
        stream = io.BytesIO(file_bytes)
        doc = DocxDocument(stream)
        
        title = filename
        sections: List[DocumentSection] = []
        full_text_list: List[str] = []
        
        current_section_title = "Introduction"
        current_level = 1
        current_paragraphs: List[str] = []

        # Extract paragraphs & headings
        for para in doc.paragraphs:
            text = para.text.strip()
            if not text:
                continue
            
            style_name = para.style.name.lower() if para.style else ""
            if "heading 1" in style_name:
                if current_paragraphs:
                    sections.append(DocumentSection(
                        title=current_section_title,
                        level=current_level,
                        content="\n".join(current_paragraphs),
                        page=1
                    ))
                    current_paragraphs = []
                current_section_title = text
                current_level = 1
            elif "heading 2" in style_name or "heading 3" in style_name:
                if current_paragraphs:
                    sections.append(DocumentSection(
                        title=current_section_title,
                        level=current_level,
                        content="\n".join(current_paragraphs),
                        page=1
                    ))
                    current_paragraphs = []
                current_section_title = text
                current_level = 2 if "heading 2" in style_name else 3
            else:
                current_paragraphs.append(text)
                full_text_list.append(text)

        if current_paragraphs:
            sections.append(DocumentSection(
                title=current_section_title,
                level=current_level,
                content="\n".join(current_paragraphs),
                page=1
            ))

        # Extract tables
        doc_tables: List[DocumentTable] = []
        for t_idx, table in enumerate(doc.tables, start=1):
            rows_data = []
            headers = []
            for r_idx, row in enumerate(table.rows):
                row_cells = [cell.text.strip() for cell in row.cells]
                if r_idx == 0:
                    headers = row_cells
                else:
                    rows_data.append(row_cells)
            
            table_obj = DocumentTable(headers=headers, rows=rows_data, caption=f"Table {t_idx}", page=1)
            doc_tables.append(table_obj)
            table_md = table_obj.to_markdown()
            full_text_list.append(table_md)
            
            sections.append(DocumentSection(
                title=f"Table: {table_obj.caption}",
                level=2,
                content=table_md,
                page=1,
                tables=[table_obj]
            ))

        combined = "\n\n".join(full_text_list)
        return ParsedDocument(
            filename=filename,
            file_type="docx",
            title=title,
            sections=sections,
            full_text=combined,
            total_pages=1,
            total_tokens=estimate_token_count(combined),
            metadata={"table_count": len(doc_tables)}
        )


class MarkdownParser:
    """Extracts hierarchical sections, code blocks, and markdown tables."""

    @staticmethod
    def parse(file_bytes: bytes, filename: str) -> ParsedDocument:
        content = file_bytes.decode("utf-8", errors="replace")
        title = filename
        
        # Look for first H1 as title
        h1_match = re.search(r"^#\s+(.+)$", content, re.MULTILINE)
        if h1_match:
            title = h1_match.group(1).strip()

        sections: List[DocumentSection] = []
        
        # Split by markdown headings
        heading_regex = re.compile(r"^(#{1,6})\s+(.+)$", re.MULTILINE)
        matches = list(heading_regex.finditer(content))
        
        if not matches:
            sections.append(DocumentSection(title="Main", level=1, content=content, page=1))
        else:
            # Add intro before first heading if exists
            if matches[0].start() > 0:
                pre_text = content[:matches[0].start()].strip()
                if pre_text:
                    sections.append(DocumentSection(title="Overview", level=1, content=pre_text, page=1))
            
            for i, match in enumerate(matches):
                level = len(match.group(1))
                sec_title = match.group(2).strip()
                start_pos = match.end()
                end_pos = matches[i + 1].start() if i + 1 < len(matches) else len(content)
                sec_content = content[start_pos:end_pos].strip()
                sections.append(DocumentSection(
                    title=sec_title,
                    level=level,
                    content=sec_content,
                    page=1
                ))

        return ParsedDocument(
            filename=filename,
            file_type="md",
            title=title,
            sections=sections,
            full_text=content,
            total_pages=1,
            total_tokens=estimate_token_count(content),
            metadata={"heading_count": len(matches)}
        )


class HTMLParser:
    """Parses HTML into cleaned hierarchical sections, extracting headers & tables."""

    @staticmethod
    def parse(file_bytes: bytes, filename: str) -> ParsedDocument:
        soup = BeautifulSoup(file_bytes, "html.parser")
        
        # Remove script and style tags
        for script in soup(["script", "style", "nav", "footer", "header"]):
            script.decompose()

        title = soup.title.string.strip() if soup.title and soup.title.string else filename

        sections: List[DocumentSection] = []
        full_text_list: List[str] = []

        headers = soup.find_all(["h1", "h2", "h3", "h4", "h5", "h6"])
        if not headers:
            body_text = soup.get_text(separator="\n", strip=True)
            sections.append(DocumentSection(title="Main", level=1, content=body_text, page=1))
            full_text_list.append(body_text)
        else:
            for h in headers:
                level = int(h.name[1])
                sec_title = h.get_text(strip=True)
                # Gather siblings until next heading
                content_parts = []
                for sibling in h.next_siblings:
                    if sibling.name in ["h1", "h2", "h3", "h4", "h5", "h6"]:
                        break
                    if hasattr(sibling, "get_text"):
                        text = sibling.get_text(strip=True)
                        if text:
                            content_parts.append(text)
                sec_text = "\n".join(content_parts)
                if sec_text:
                    sections.append(DocumentSection(title=sec_title, level=level, content=sec_text, page=1))
                    full_text_list.append(f"## {sec_title}\n{sec_text}")

        combined = "\n\n".join(full_text_list)
        return ParsedDocument(
            filename=filename,
            file_type="html",
            title=title,
            sections=sections,
            full_text=combined,
            total_pages=1,
            total_tokens=estimate_token_count(combined),
            metadata={"html_tags_cleaned": True}
        )


class CSVParser:
    """Parses CSV into tabular markdown representation and column-wise summaries."""

    @staticmethod
    def parse(file_bytes: bytes, filename: str) -> ParsedDocument:
        text = file_bytes.decode("utf-8", errors="replace")
        stream = io.StringIO(text)
        reader = csv.reader(stream)
        
        rows = list(reader)
        if not rows:
            return ParsedDocument(filename=filename, file_type="csv", title=filename, full_text="", sections=[])

        headers = rows[0]
        data_rows = rows[1:]

        table = DocumentTable(headers=headers, rows=data_rows, caption=f"Dataset: {filename}", page=1)
        table_md = table.to_markdown()

        # Build natural language summary rows for higher embedding retrieval quality
        summary_lines = [f"CSV Dataset: {filename}", f"Columns: {', '.join(headers)}", f"Total Rows: {len(data_rows)}", ""]
        for idx, row in enumerate(data_rows, start=1):
            row_repr = ", ".join([f"{h}: {val}" for h, val in zip(headers, row) if val])
            summary_lines.append(f"Record {idx}: {row_repr}")

        combined = table_md + "\n\n" + "\n".join(summary_lines)
        section = DocumentSection(title=f"Data: {filename}", level=1, content=combined, page=1, tables=[table])

        return ParsedDocument(
            filename=filename,
            file_type="csv",
            title=filename,
            sections=[section],
            full_text=combined,
            total_pages=1,
            total_tokens=estimate_token_count(combined),
            metadata={"columns": headers, "row_count": len(data_rows)}
        )


class TextParser:
    """Parses plain TXT documents, detecting paragraph structures."""

    @staticmethod
    def parse(file_bytes: bytes, filename: str) -> ParsedDocument:
        content = file_bytes.decode("utf-8", errors="replace").strip()
        paragraphs = [p.strip() for p in content.split("\n\n") if p.strip()]
        
        sections: List[DocumentSection] = []
        for idx, p in enumerate(paragraphs, start=1):
            sections.append(DocumentSection(
                title=f"Paragraph {idx}",
                level=2,
                content=p,
                page=1
            ))

        return ParsedDocument(
            filename=filename,
            file_type="txt",
            title=filename,
            sections=sections,
            full_text=content,
            total_pages=1,
            total_tokens=estimate_token_count(content),
            metadata={"paragraph_count": len(paragraphs)}
        )


class DocumentParserRouter:
    """Central router mapping file extensions and mime types to optimal parsers."""

    @classmethod
    def parse(cls, file_bytes: bytes, filename: str, mime_type: Optional[str] = None) -> ParsedDocument:
        ext = os.path.splitext(filename)[1].lower().lstrip(".")
        logger.info(f"Parsing document '{filename}' of detected extension '{ext}' (size: {len(file_bytes)} bytes)")

        if ext == "pdf":
            return PDFParser.parse(file_bytes, filename)
        elif ext in ["docx", "doc"]:
            return DocxParser.parse(file_bytes, filename)
        elif ext in ["md", "markdown"]:
            return MarkdownParser.parse(file_bytes, filename)
        elif ext in ["html", "htm"]:
            return HTMLParser.parse(file_bytes, filename)
        elif ext in ["csv", "tsv"]:
            return CSVParser.parse(file_bytes, filename)
        else:
            return TextParser.parse(file_bytes, filename)
