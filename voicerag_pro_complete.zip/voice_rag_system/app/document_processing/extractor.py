"""
Document Entity, Section, Table, and Chunk Data Models with Rich Metadata.
"""

import uuid
import time
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


class DocumentTable(BaseModel):
    headers: List[str] = Field(default_factory=list)
    rows: List[List[str]] = Field(default_factory=list)
    caption: Optional[str] = None
    page: int = 1

    def to_markdown(self) -> str:
        if not self.headers and not self.rows:
            return ""
        lines = []
        if self.caption:
            lines.append(f"**Table: {self.caption}**")
        if self.headers:
            lines.append("| " + " | ".join(self.headers) + " |")
            lines.append("| " + " | ".join(["---"] * len(self.headers)) + " |")
        for row in self.rows:
            lines.append("| " + " | ".join(str(cell) for cell in row) + " |")
        return "\n".join(lines)


class DocumentSection(BaseModel):
    title: str = "General"
    level: int = 1
    content: str
    page: int = 1
    tables: List[DocumentTable] = Field(default_factory=list)


class ParsedDocument(BaseModel):
    doc_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    filename: str
    file_type: str  # 'pdf', 'docx', 'md', 'txt', 'csv', 'html'
    title: str
    sections: List[DocumentSection] = Field(default_factory=list)
    full_text: str
    total_pages: int = 1
    total_tokens: int = 0
    created_at: float = Field(default_factory=time.time)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class DocumentChunk(BaseModel):
    chunk_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    doc_id: str
    parent_id: Optional[str] = None  # Populated for Parent-Child chunking
    text: str
    token_count: int
    strategy: str  # 'semantic', 'recursive', 'parent_child', 'sliding', 'sentence'
    page: int = 1
    section_title: str = "General"
    heading_hierarchy: List[str] = Field(default_factory=list)
    paragraph_index: int = 0
    metadata: Dict[str, Any] = Field(default_factory=dict)
    embedding: Optional[List[float]] = None
