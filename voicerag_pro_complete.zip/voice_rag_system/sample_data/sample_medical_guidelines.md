# Clinical Practice Guidelines: Hypertension Management & Cardiovascular Risk Protocol (2026)

## Section 1: Diagnostic Blood Pressure Classifications
Blood pressure classifications for adult patients (aged >= 18) are defined as follows:
- Normal Blood Pressure: Systolic < 120 mmHg and Diastolic < 80 mmHg.
- Elevated Blood Pressure: Systolic 120-129 mmHg and Diastolic < 80 mmHg.
- Stage 1 Hypertension: Systolic 130-139 mmHg or Diastolic 80-89 mmHg.
- Stage 2 Hypertension: Systolic >= 140 mmHg or Diastolic >= 90 mmHg.
- Hypertensive Crisis: Systolic > 180 mmHg and/or Diastolic > 120 mmHg, necessitating immediate emergency medical intervention.

## Section 2: First-Line Pharmacological Interventions
For patients diagnosed with Stage 2 Hypertension or Stage 1 Hypertension with high atherosclerotic cardiovascular disease (ASCVD) risk (>10% 10-year risk):
1. Angiotensin-Converting Enzyme (ACE) Inhibitors: Lisinopril initial dose 10 mg daily (titrate up to 40 mg daily).
2. Angiotensin II Receptor Blockers (ARBs): Losartan initial dose 50 mg daily (titrate up to 100 mg daily).
3. Calcium Channel Blockers (CCBs): Amlodipine initial dose 5 mg daily (titrate up to 10 mg daily).
4. Thiazide Diuretics: Chlorthalidone initial dose 12.5 mg daily (titrate up to 25 mg daily) or Hydrochlorothiazide 25 mg daily.

## Section 3: Lifestyle Modification & Monitoring Frequencies
All hypertensive patients should adopt non-pharmacological interventions:
- Sodium restriction to < 1500 mg/day (DASH diet protocol).
- Minimum 150 minutes per week of moderate-intensity aerobic physical exercise.
- Potassium supplementation: 3500-5000 mg/day through dietary sources.
- Follow-up evaluation is scheduled at 4-week intervals until target blood pressure (< 130/80 mmHg) is consistently attained.
